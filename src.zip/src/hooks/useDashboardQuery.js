// src/hooks/useDashboardQuery.js
import { useQuery } from "@tanstack/react-query";
import supabase from "@/services/supabaseClient";

// Kandidat RPC (sesuaikan nama RPC "terbaru" Anda)
const RPC_BUNDLE_CANDIDATES = [
  // jika Anda punya 1 RPC yang mengembalikan semua data dashboard sekaligus (json)
  "rpc_dashboard_bundle",
  "rpc_dashboard_data",
];

const RPC_STATS_CANDIDATES = ["get_dashboard_stats", "rpc_dashboard_stats"];

const RPC_KEGIATAN_SUMMARY_CANDIDATES = [
  "rpc_kegiatan_summary_by_jenjang",
  "rpc_dashboard_kegiatan_summary_by_jenjang",
];

const RPC_KONDISI_SUMMARY_CANDIDATES = [
  "rpc_kelas_kondisi_summary_by_jenjang",
  "rpc_dashboard_kelas_kondisi_summary_by_jenjang",
];

const RPC_KECAMATAN_LIST_CANDIDATES = [
  "get_unique_kecamatan",
  "rpc_unique_kecamatan",
  "rpc_kecamatan_list",
];

const RPC_RANKING_SCHOOLS_CANDIDATES = [
  "rpc_dashboard_school_ranking",
  "rpc_school_ranking",
  "rpc_dashboard_ranking_schools",
];

async function rpcFirstAvailable(functionNames, args) {
  let lastErr = null;

  for (const fn of functionNames) {
    const { data, error } = await supabase.rpc(fn, args || {});
    if (!error) return { data, rpc: fn };

    lastErr = error;

    const msg = String(error?.message || "");
    const code = String(error?.code || "");

    const isNotFound =
      code === "PGRST202" ||
      /could not find the function/i.test(msg) ||
      /function .* does not exist/i.test(msg) ||
      /schema cache/i.test(msg);

    if (isNotFound) continue;

    throw error;
  }

  if (lastErr) throw lastErr;
  throw new Error("RPC failed (no candidate succeeded).");
}

const fetchDashboardData = async () => {
  // 0) Coba bundle RPC (opsional)
  try {
    const bundle = await rpcFirstAvailable(RPC_BUNDLE_CANDIDATES, {});
    const d = bundle?.data;

    // Jika bundle mengembalikan object terstruktur
    if (d && typeof d === "object" && !Array.isArray(d)) {
      return {
        stats: d.stats || {},
        kegiatanSummary: d.kegiatanSummary || d.kegiatan_summary || [],
        kondisiSummary: d.kondisiSummary || d.kondisi_summary || [],
        schoolsForRanking: d.schoolsForRanking || d.schools_ranking || [],
        allKecamatan: d.allKecamatan || d.kecamatan || [],
      };
    }
  } catch {
    // fallback ke pemanggilan RPC terpisah
  }

  // 1) Statistik Utama
  const statsRes = await rpcFirstAvailable(RPC_STATS_CANDIDATES, {});
  const statsData = statsRes?.data || {};

  // 2) Rekap Kegiatan
  const kegiatanRes = await rpcFirstAvailable(RPC_KEGIATAN_SUMMARY_CANDIDATES, {});
  const kegiatanSummaryData = kegiatanRes?.data || [];

  // 3) Rekap Kondisi
  const kondisiRes = await rpcFirstAvailable(RPC_KONDISI_SUMMARY_CANDIDATES, {});
  const kondisiSummaryData = kondisiRes?.data || [];

  // 4) Ranking sekolah/top wilayah (opsional, jika RPC tersedia)
  let schoolsForRanking = [];
  try {
    const rankingRes = await rpcFirstAvailable(RPC_RANKING_SCHOOLS_CANDIDATES, {});
    schoolsForRanking = rankingRes?.data || [];
  } catch {
    schoolsForRanking = [];
  }

  // 5) List Kecamatan unik
  let allKecamatan = [];
  try {
    const kecRes = await rpcFirstAvailable(RPC_KECAMATAN_LIST_CANDIDATES, {});
    allKecamatan = kecRes?.data || [];
  } catch {
    allKecamatan = [];
  }

  return {
    stats: statsData,
    kegiatanSummary: kegiatanSummaryData,
    kondisiSummary: kondisiSummaryData,
    schoolsForRanking,
    allKecamatan,
  };
};

export function useDashboardQuery() {
  return useQuery({
    queryKey: ["dashboardData"],
    queryFn: fetchDashboardData,
    staleTime: 1000 * 60 * 5,
    cacheTime: 1000 * 60 * 30,
    refetchOnWindowFocus: false,
  });
}
