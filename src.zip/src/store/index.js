// src/store/index.js
export { default } from './store'
