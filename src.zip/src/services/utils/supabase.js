export { supabase as default, supabase } from '../services/supabaseClient';
