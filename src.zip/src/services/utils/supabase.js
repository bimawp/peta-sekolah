// src/services/utils/supabase.js
// Re-export client Supabase dari satu sumber utama

export { default as supabase } from '../supabaseClient';
export { default } from '../supabaseClient';
