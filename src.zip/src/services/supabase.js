// src/services/supabase.js
// Alias untuk client Supabase utama

export { default as supabase } from '@/services/supabaseClient';
export { default } from '@/services/supabaseClient';
