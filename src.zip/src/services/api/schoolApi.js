// src/services/api/schoolApi.js
import supabase from "@/services/supabaseClient";

/** =========================
 *  Utils
 *  ========================= */
const CHUNK_SIZE = 20; // kecil supaya URL PostgREST aman

function chunkArray(arr, size = CHUNK_SIZE) {
  if (!Array.isArray(arr) || arr.length === 0) return [];
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

const ensureArray = (x) => (Array.isArray(x) ? x : x ? [x] : []);

async function selectAll(table, columns = "*") {
  const { data, error } = await supabase.from(table).select(columns);
  if (error) throw error;
  return data || [];
}

const isAll = (v) => {
  if (v == null) return true;
  const s = String(v).trim().toUpperCase();
  return s === "" || s === "SEMUA" || s === "ALL" || s === "*" || s === "NULL";
};

const normFilter = (v) => (isAll(v) ? null : v);

/** =========================
 *  Schools
 *  ========================= */
export async function fetchAllSchools(columns = "*") {
  return selectAll("schools", columns);
}

export async function getSchoolById(id, columns = "*") {
  const { data, error } = await supabase.from("schools").select(columns).eq("id", id).single();
  if (error) throw error;
  return data;
}

/** =========================
 *  RPC helpers
 *  ========================= */
async function tryRpc(rpcName, payload) {
  const { data, error } = await supabase.rpc(rpcName, payload);
  if (error) return { ok: false, data: null, error };
  return { ok: true, data: data ?? null };
}

/** =========================
 *  Helper: Schools by Filters
 *  =========================
 *  Pengganti rpc_schools_by_filters (tidak ada di Supabase Anda)
 *
 *  Prioritas RPC:
 *   1) get_schools_paginated
 *   2) get_schools_map_data
 *   3) rpc_map_schools
 *  Fallback:
 *   - schools_with_details (karena ada kolom jenjang/kecamatan/village)
 */
async function fetchSchoolsByFilters(filters = {}) {
  const level = normFilter(filters?.level);
  const kecamatan = normFilter(filters?.kecamatan);
  const village = normFilter(filters?.village);

  // -------- 1) Coba: get_schools_paginated
  // Catatan: signature bisa berbeda, jadi saya coba beberapa payload umum.
  // Kita set page_size besar supaya dapat "semua" (untuk kebutuhan dataset).
  const paginatedPayloads = [
    { p_page: 1, p_page_size: 10000, p_jenjang: level, p_kecamatan: kecamatan, p_desa: village },
    { page: 1, page_size: 10000, jenjang: level, kecamatan, desa: village },
    { _page: 1, _page_size: 10000, _jenjang: level, _kecamatan: kecamatan, _desa: village },
  ];

  for (const payload of paginatedPayloads) {
    const res = await tryRpc("get_schools_paginated", payload);
    if (!res.ok) continue;

    // Bisa mengembalikan:
    // - array langsung
    // - object { rows: [...], total: n, ... }
    // - object lain yang berisi list
    const d = res.data;

    if (Array.isArray(d)) return d;

    if (d && Array.isArray(d.rows)) return d.rows;
    if (d && Array.isArray(d.data)) return d.data;
    if (d && Array.isArray(d.items)) return d.items;
  }

  // -------- 2) Coba: get_schools_map_data
  // (biasanya untuk peta, tapi cukup untuk list id+koordinat+atribut ringkas)
  const mapDataPayloads = [
    { p_jenjang: level, p_kecamatan: kecamatan, p_desa: village },
    { jenjang: level, kecamatan, desa: village },
    { _jenjang: level, _kecamatan: kecamatan, _desa: village },
  ];

  for (const payload of mapDataPayloads) {
    const res = await tryRpc("get_schools_map_data", payload);
    if (!res.ok) continue;

    const d = res.data;
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.rows)) return d.rows;
    if (d && Array.isArray(d.data)) return d.data;
    if (d && Array.isArray(d.items)) return d.items;
  }

  // -------- 3) Coba: rpc_map_schools
  for (const payload of mapDataPayloads) {
    const res = await tryRpc("rpc_map_schools", payload);
    if (!res.ok) continue;

    const d = res.data;
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.rows)) return d.rows;
    if (d && Array.isArray(d.data)) return d.data;
    if (d && Array.isArray(d.items)) return d.items;
  }

  // -------- Fallback: schools_with_details
  // Karena Anda punya kolom: jenjang, kecamatan, village, lat, lng, id, npsn, name, dll.
  let q = supabase
    .from("schools_with_details")
    .select("id,name,npsn,address,status,student_count,st_male,st_female,lat,lng,jenjang,kecamatan,village");

  if (level) q = q.eq("jenjang", String(level));
  if (kecamatan) q = q.eq("kecamatan", String(kecamatan));
  if (village) q = q.eq("village", String(village));

  const { data, error } = await q;
  if (error) throw error;

  return data || [];
}

/** =========================
 *  Kegiatan
 *  ========================= */
export async function fetchAllKegiatanBySchoolIds(ids = [], columns = "*") {
  // columns tidak dipakai lagi; data diambil lewat RPC kegiatan_by_school_ids(sids uuid[])
  const list = Array.isArray(ids) ? ids : [];
  if (list.length === 0) return [];

  const chunks = chunkArray(list);
  const results = await Promise.all(
    chunks.map(async (c) => {
      const { data, error } = await supabase.rpc("kegiatan_by_school_ids", { sids: c });
      if (error) throw error;
      return data || [];
    })
  );

  return results.flat();
}

/** =========================
 *  Class Conditions
 *  ========================= */
export async function fetchClassConditionsBySchoolIds(ids = []) {
  const list = Array.isArray(ids) ? ids : [];
  if (list.length === 0) return [];

  const chunks = chunkArray(list);
  const results = await Promise.all(
    chunks.map(async (c) => {
      const { data, error } = await supabase.rpc("class_conditions_by_school_ids", { sids: c });
      if (error) throw error;
      return data || [];
    })
  );

  return results.flat();
}

/** =========================
 *  Load dataset (untuk SchoolDetailPage)
 *  =========================
 *  Input: filters { level, kecamatan, village }
 *  Output: array sekolah "merged" + relasi & coordinates
 */
export async function loadSchoolDatasetRPC(filters = {}) {
  // 1) Ambil sekolah sesuai filter (RPC yang ada + fallback view)
  const schools = await fetchSchoolsByFilters(filters);
  if (!schools.length) return [];

  // Pastikan ada id (uuid) karena RPC kegiatan/class_conditions pakai school_id.
  const sids = schools.map((s) => s.id).filter(Boolean);
  if (!sids.length) return [];

  // 2) Coba RPC, fallback ke select biasa (tetap pakai RPC utama)
  const [kegRpc, ccRpc] = await Promise.all([
    tryRpc("kegiatan_by_school_ids", { sids }),
    tryRpc("class_conditions_by_school_ids", { sids }),
  ]);

  const kegiatan = kegRpc.ok
    ? ensureArray(kegRpc.data)
    : await fetchAllKegiatanBySchoolIds(sids, "id,school_id,kegiatan,lokal,created_at,updated_at");

  const classConditions = ccRpc.ok ? ensureArray(ccRpc.data) : await fetchClassConditionsBySchoolIds(sids);

  // 3) Index relasi per school_id
  const kegBySchool = new Map();
  for (const k of kegiatan) {
    if (!k || !k.school_id) continue;
    if (!kegBySchool.has(k.school_id)) kegBySchool.set(k.school_id, []);
    kegBySchool.get(k.school_id).push(k);
  }

  // diasumsikan 1 row class_conditions per sekolah
  const ccBySchool = new Map();
  for (const c of classConditions) {
    if (!c || !c.school_id) continue;
    ccBySchool.set(c.school_id, c);
  }

  // 4) Merge: bentuk array sesuai ekspektasi SchoolDetailPage
  const merged = schools.map((s) => {
    const hasNumber = (v) => typeof v === "number" && !Number.isNaN(v);

    // Support beberapa kemungkinan field desa dari sumber berbeda:
    const desaValue =
      s.village ??
      s.village_name ?? // kalau suatu saat pakai tabel schools langsung
      s.desa ??
      (s.meta && typeof s.meta === "object" ? s.meta.desa : undefined) ??
      null;

    const coords = hasNumber(s.lng) && hasNumber(s.lat) ? [s.lng, s.lat] : null;

    return {
      ...s,
      desa: desaValue,
      coordinates: coords,
      kegiatan: kegBySchool.get(s.id) || [],
      class_conditions: ccBySchool.get(s.id) || null,
    };
  });

  return merged;
}

/** =========================
 *  Dashboard
 *  ========================= */
export async function getDashboardStats() {
  const { data, error } = await supabase.rpc("get_dashboard_stats");
  if (error) throw error;
  return data;
}
