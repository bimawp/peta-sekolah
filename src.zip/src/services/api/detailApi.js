// src/services/api/detailApi.js
// Versi ringan: SUPABASE ONLY (tanpa fetch JSON besar) + timing log
// Struktur data DIJAGA sesuai SchoolDetailSmp.jsx

import supabase from '../supabaseClient';

const int = (v, d = 0) => {
  if (v === null || v === undefined) return d;
  const n = Number(v);
  return Number.isNaN(n) ? d : n;
};

const one = (arr) => (Array.isArray(arr) && arr.length ? arr[0] : null);

const emptyLabPack = () => ({
  laboratory_comp:   { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
  laboratory_langua: { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
  laboratory_ipa:    { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
  laboratory_fisika: { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
  laboratory_biologi:{ good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
});

const EMPTY_TOILET_GENDER = { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 };
const emptyToilets = () => ({
  teachers_toilet: { male: { ...EMPTY_TOILET_GENDER }, female: { ...EMPTY_TOILET_GENDER }, _overall: { good:0, moderate_damage:0, heavy_damage:0, total:0 } },
  students_toilet: { male: { ...EMPTY_TOILET_GENDER }, female: { ...EMPTY_TOILET_GENDER }, _overall: { good:0, moderate_damage:0, heavy_damage:0, total:0 } },
});

const mapLabKey = (lab_type) => {
  if (!lab_type) return null;
  const s = String(lab_type).toLowerCase();
  if (s.includes('komputer')) return 'laboratory_comp';
  if (s.includes('bahasa'))   return 'laboratory_langua';
  if (s.includes('ipa'))      return 'laboratory_ipa';
  if (s.includes('fisika'))   return 'laboratory_fisika';
  if (s.includes('biologi'))  return 'laboratory_biologi';
  return null;
};

const mapRoomKey = (room_type) => {
  if (!room_type) return null;
  const s = String(room_type).toLowerCase();
  if (s.includes('kepala')) return 'kepsek_room';
  if (s.includes('guru'))   return 'teacher_room';
  if (s.includes('tata') || s.includes('administrasi') || s.includes('administration'))
    return 'administration_room';
  return null;
};

export async function getSmpDetailByNpsn(npsn) {
  const t0 = performance.now();
  console.log('[detailApi][start] npsn =', npsn);

  // 1) Ambil school
  const { data: school, error: eSchool } = await supabase
    .from('schools')
    .select('id,name,npsn,address,village,kecamatan,student_count,lat,lng,latitude,longitude')
    .eq('npsn', npsn)
    .maybeSingle();

  if (eSchool) {
    console.warn('[detailApi][schools][error]', eSchool);
    return null;
  }
  if (!school) {
    console.log('[detailApi] school not found for npsn', npsn);
    return null;
  }

  const schoolId = school.id;
  const lat = school.lat != null ? Number(school.lat) : (school.latitude != null ? Number(school.latitude) : null);
  const lng = school.lng != null ? Number(school.lng) : (school.longitude != null ? Number(school.longitude) : null);

  const base = {
    id: schoolId,
    name: school.name || '-',
    npsn: school.npsn || '-',
    address: school.address || '-',
    village: school.village || '-',
    kecamatan: school.kecamatan || '-',
    student_count: int(school.student_count, 0),
    coordinates: (typeof lat === 'number' && typeof lng === 'number') ? [lat, lng] : null,
  };

  const t1 = performance.now();

  // 2) Query paralel ke tabel fakta
  const [
    { data: ccRows, error: eCC },
    { data: libRows, error: eLib },
    { data: labRows, error: eLab },
    { data: roomRows, error: eRoom },
    { data: toiletRows, error: eToilet },
    { data: fcompRows, error: eFComp },
    { data: officRows, error: eOffic },
    { data: kegRows, error: eKeg },
  ] = await Promise.all([
    supabase.from('class_conditions').select('*').eq('school_id', schoolId).limit(1),
    supabase.from('library').select('*').eq('school_id', schoolId).limit(1),
    supabase.from('laboratory').select('*').eq('school_id', schoolId),
    supabase.from('teacher_room').select('*').eq('school_id', schoolId),
    supabase.from('toilets').select('*').eq('school_id', schoolId),
    supabase.from('furniture_computer').select('*').eq('school_id', schoolId).limit(1),
    supabase.from('official_residences').select('*').eq('school_id', schoolId).limit(1),
    supabase.from('kegiatan').select('kegiatan,lokal').eq('school_id', schoolId),
  ]);

  const t2 = performance.now();

  // Log ringkas & timing
  console.log('[detailApi][timing] school(ms)=', Math.round(t1 - t0), ' facts(ms)=', Math.round(t2 - t1), ' total(ms)=', Math.round(t2 - t0));
  if (eCC)    console.warn('[detailApi][class_conditions][error]', eCC);
  if (eLib)   console.warn('[detailApi][library][error]', eLib);
  if (eLab)   console.warn('[detailApi][laboratory][error]', eLab);
  if (eRoom)  console.warn('[detailApi][teacher_room][error]', eRoom);
  if (eToilet)console.warn('[detailApi][toilets][error]', eToilet);
  if (eFComp) console.warn('[detailApi][furniture_computer][error]', eFComp);
  if (eOffic) console.warn('[detailApi][official_residences][error]', eOffic);
  if (eKeg)   console.warn('[detailApi][kegiatan][error]', eKeg);

  // 3) Bentuk struktur sesuai komponen
  const cc = one(ccRows) || {};
  const ccGood  = int(cc.classrooms_good, 0);
  const ccMod   = int(cc.classrooms_moderate_damage, 0);
  const ccHeavy = int(cc.classrooms_heavy_damage, 0);

  const class_condition = {
    classrooms_good: ccGood,
    classrooms_moderate_damage: ccMod,
    classrooms_heavy_damage: ccHeavy,
    total_room: int(cc.total_room, 0),
    lacking_rkb: int(cc.lacking_rkb, 0),
    total_mh: ccMod + ccHeavy,
  };

  const lib = one(libRows) || {};
  const library = {
    good: int(lib.good, 0),
    moderate_damage: int(lib.moderate_damage, 0),
    heavy_damage: int(lib.heavy_damage, 0),
    total_mh: int(lib.moderate_damage, 0) + int(lib.heavy_damage, 0),
    total_all: lib.total != null
      ? int(lib.total, 0)
      : int(lib.good, 0) + int(lib.moderate_damage, 0) + int(lib.heavy_damage, 0),
  };

  const labObj = emptyLabPack();
  (labRows || []).forEach((r) => {
    const k = mapLabKey(r.lab_type);
    if (!k) return;
    const good = int(r.good, 0);
    const mod  = int(r.moderate_damage, 0);
    const heavy= int(r.heavy_damage, 0);
    labObj[k] = {
      good,
      moderate_damage: mod,
      heavy_damage: heavy,
      total_mh: r.total_mh != null ? int(r.total_mh) : (mod + heavy),
      total_all: r.total_all != null ? int(r.total_all) : (good + mod + heavy),
    };
  });

  const roomObj = {
    kepsek_room:         { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
    teacher_room:        { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
    administration_room: { good: 0, moderate_damage: 0, heavy_damage: 0, total_mh: 0, total_all: 0 },
  };
  (roomRows || []).forEach((r) => {
    const k = mapRoomKey(r.room_type);
    if (!k) return;
    const good = int(r.good, 0);
    const mod  = int(r.moderate_damage, 0);
    const heavy= int(r.heavy_damage, 0);
    roomObj[k] = {
      good,
      moderate_damage: mod,
      heavy_damage: heavy,
      total_mh: r.total_mh != null ? int(r.total_mh) : (mod + heavy),
      total_all: r.total_all != null ? int(r.total_all) : (good + mod + heavy),
    };
  });

  const toilets = emptyToilets();
  (toiletRows || []).forEach((r) => {
    const key =
      String(r.type || '').toLowerCase().includes('guru') ? 'teachers_toilet'
      : String(r.type || '').toLowerCase().includes('siswa') ? 'students_toilet'
      : null;
    if (!key) return;
    toilets[key] = {
      male:   { ...EMPTY_TOILET_GENDER, total_all: int(r.male, 0) },
      female: { ...EMPTY_TOILET_GENDER, total_all: int(r.female, 0) },
      _overall: {
        good: int(r.good, 0),
        moderate_damage: int(r.moderate_damage, 0),
        heavy_damage: int(r.heavy_damage, 0),
        total: int(r.total, int(r.good,0) + int(r.moderate_damage,0) + int(r.heavy_damage,0)),
      },
    };
  });

  const fcomp = one(fcompRows) || {};
  const furniture_computer = {
    tables: int(fcomp.tables, 0),
    chairs: int(fcomp.chairs, 0),
    boards: int(fcomp.boards, 0),
    computer: int(fcomp.computer, 0),
  };

  const offic = one(officRows) || {};
  const official_residences = {
    total: int(offic.total, 0),
    good: int(offic.good, 0),
    moderate_damage: int(offic.moderate_damage, 0),
    heavy_damage: int(offic.heavy_damage, 0),
  };

  const pembangunanRKB = (kegRows || [])
    .filter((r) => String(r.kegiatan || '').toLowerCase().includes('pembangunan'))
    .reduce((acc, r) => acc + int(r.lokal, 0), 0);

  const result = {
    ...base,
    class_condition,
    library,
    ...labObj,
    ...roomObj,
    ...toilets,
    furniture_computer,
    official_residences,
    pembangunanRKB,
  };

  console.log('[detailApi][done] result =', result);
  return result;
}
