import React from 'react';
import styles from './Analytics.module.css';

const Analytics = () => {
  return (
    <div className={styles.analytics}>
      <h1>Analitik</h1>
      {/* Tambahkan grafik dan statistik */}
    </div>
  );
};

export default Analytics;
