// src/pages/SchoolDetail/DetailSekolahWrapper.jsx - GANTI SELURUH ISI FILE INI

import React from 'react';
import SchoolDetailPage from './SchoolDetailPage';

const DetailSekolahWrapper = () => {
  return (
    <div>
      <SchoolDetailPage />
    </div>
  );
};

export default DetailSekolahWrapper;