import React from 'react';
import styles from './Settings.module.css';

const Settings = () => {
  return (
    <div className={styles.settings}>
      <h1>Pengaturan</h1>
      {/* Pengaturan aplikasi */}
    </div>
  );
};

export default Settings;
