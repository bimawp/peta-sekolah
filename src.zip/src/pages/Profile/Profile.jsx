import React from 'react';
import styles from './Profile.module.css';

const Profile = () => {
  return (
    <div className={styles.profile}>
      <h1>Profil Saya</h1>
      {/* Informasi user, edit profil */}
    </div>
  );
};

export default Profile;
