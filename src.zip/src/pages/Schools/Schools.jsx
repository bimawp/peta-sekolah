import React from 'react';
import styles from './Schools.module.css';

const Schools = () => {
  return (
    <div className={styles.schools}>
      <h1>Daftar Sekolah</h1>
      {/* Tambahkan komponen tabel sekolah atau filter */}
    </div>
  );
};

export default Schools;
