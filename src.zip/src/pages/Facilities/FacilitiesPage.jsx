// src/pages/Facilities/FacilitiesPage.jsx
import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  Suspense,
  memo,
  lazy,
  startTransition,
  useDeferredValue,
} from "react";
import styles from "./FacilitiesPage.module.css";

const ChartsSection = lazy(() => import("./ChartsSection"));
import ChartSkeleton from "./ChartSkeleton";
import ErrorBoundary from "@/components/common/ErrorBoundary.jsx";

// Detail di tab baru (tetap lazy)
const SchoolDetailPaud = lazy(() =>
  import("../../components/schools/SchoolDetail/Paud/SchoolDetailPaud")
);
const SchoolDetailSd = lazy(() =>
  import("../../components/schools/SchoolDetail/Sd/SchoolDetailSd")
);
const SchoolDetailSmp = lazy(() =>
  import("../../components/schools/SchoolDetail/Smp/SchoolDetailSmp")
);
const SchoolDetailPkbm = lazy(() =>
  import("../../components/schools/SchoolDetail/Pkbm/SchoolDetailPkbm")
);

import {
  getSdDetailByNpsn,
  getSmpDetailByNpsn,
  getPaudDetailByNpsn,
  getPkbmDetailByNpsn,
} from "@/services/api/detailApi";

// Supabase hanya untuk data sekolah & kegiatan,
// filter kecamatan/desa tetap murni dari JSON.
import supabase from "@/services/supabaseClient";

/* =====================================================================
   RPC (TERBARU) - sesuaikan nama function Anda di Supabase
   ===================================================================== */
const RPC_TOILET_SCHOOLS_CANDIDATES = [
  // kandidat 1-2 yang paling umum
  "rpc_facilities_toilet_schools",
  "rpc_facilities_toilet_school_list",

  // fallback lain (jika Anda menamai berbeda)
  "rpc_toilet_schools",
  "rpc_facilities_schools_toilet",
  "rpc_facilities_toilet_dataset_schools",
];

const RPC_TOILET_PROJECTS_CANDIDATES = [
  "rpc_facilities_toilet_projects",
  "rpc_facilities_toilet_project_list",
  "rpc_toilet_projects",
  "rpc_facilities_projects_toilet",
  "rpc_facilities_toilet_dataset_projects",
];

/**
 * Coba panggil RPC dari list kandidat (urut).
 * - Jika function tidak ada, lanjut ke kandidat berikutnya.
 * - Jika error selain "function not found", throw.
 */
async function rpcFirstAvailable(functionNames, args) {
  let lastErr = null;

  for (const fn of functionNames) {
    const { data, error } = await supabase.rpc(fn, args || {});
    if (!error) return { data, rpc: fn };

    lastErr = error;

    const msg = String(error?.message || "");
    const code = String(error?.code || "");

    const isNotFound =
      code === "PGRST202" ||
      /could not find the function/i.test(msg) ||
      /function .* does not exist/i.test(msg) ||
      /schema cache/i.test(msg);

    if (isNotFound) continue;

    throw error;
  }

  // Jika semua kandidat gagal, lempar error terakhir agar jelas di UI
  if (lastErr) throw lastErr;
  throw new Error("RPC failed (no candidate succeeded).");
}

/** Normalisasi aman: dukung beberapa variasi nama field dari RPC */
function pickFirst(obj, keys, fallback = null) {
  for (const k of keys) {
    const v = obj?.[k];
    if (v !== undefined && v !== null) return v;
  }
  return fallback;
}

function ensureObject(x) {
  return x && typeof x === "object" ? x : {};
}

/**
 * Map row dari RPC -> bentuk yang dipakai normalizeSchoolData()
 * Target minimal:
 * { npsn, name, jenjang, village, kecamatan, type/status, toilets, teachers_toilet, students_toilet, student_count }
 */
function mapRpcSchoolRowToLegacyShape(row) {
  const meta = ensureObject(row?.meta);

  const jenjangRaw =
    pickFirst(row, ["jenjang", "level", "school_level", "school_type_code", "code"], "") ||
    pickFirst(meta, ["jenjang", "level", "school_level", "school_type_code", "code"], "");

  const jenjang = String(jenjangRaw || "").toUpperCase();

  // toilets bisa dalam meta.toilets atau kolom terpisah
  const toiletsObj =
    pickFirst(row, ["toilets"], null) ??
    pickFirst(meta, ["toilets"], null) ??
    {
      good: pickFirst(row, ["toilet_good", "toilet_baik", "good_toilet"], 0),
      moderate_damage: pickFirst(
        row,
        ["toilet_moderate_damage", "toilet_rusak_sedang", "moderate_toilet"],
        0
      ),
      heavy_damage: pickFirst(
        row,
        ["toilet_heavy_damage", "toilet_rusak_berat", "heavy_toilet"],
        0
      ),
    };

  const teachersToiletObj =
    pickFirst(row, ["teachers_toilet"], null) ??
    pickFirst(meta, ["teachers_toilet"], null) ??
    {};

  const studentsToiletObj =
    pickFirst(row, ["students_toilet"], null) ??
    pickFirst(meta, ["students_toilet"], null) ??
    {};

  return {
    npsn: pickFirst(row, ["npsn"], ""),
    name: pickFirst(row, ["name", "nama", "nama_sekolah"], ""),
    jenjang,
    village: pickFirst(row, ["village", "desa", "village_name"], null),
    kecamatan: pickFirst(row, ["kecamatan", "subdistrict", "district"], null),
    type: pickFirst(row, ["type", "tipe", "status"], null),
    status: pickFirst(row, ["status", "type"], null),
    toilets: ensureObject(toiletsObj),
    teachers_toilet: ensureObject(teachersToiletObj),
    students_toilet: ensureObject(studentsToiletObj),
    student_count: pickFirst(row, ["student_count", "siswa", "jumlah_siswa"], 0),
  };
}

/* =====================================================================
   Helpers: cache detail di sessionStorage agar hover "Detail" terasa cepat
===================================================================== */
const CACHE_PREFIX = "sch-detail:";
const getCacheKey = (jenjang, npsn) => `${CACHE_PREFIX}${jenjang}:${npsn}`;

function readDetailCache(jenjang, npsn) {
  try {
    const raw = sessionStorage.getItem(getCacheKey(jenjang, npsn));
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && parsed.data ? parsed.data : null;
  } catch {
    return null;
  }
}

function writeDetailCache(jenjang, npsn, data) {
  try {
    sessionStorage.setItem(
      getCacheKey(jenjang, npsn),
      JSON.stringify({ ts: Date.now(), data })
    );
  } catch {}
}

async function prefetchDetailByNpsn(jenjang, npsn) {
  if (!jenjang || !npsn) return;
  if (readDetailCache(jenjang, npsn)) return;
  try {
    let data = null;
    if (jenjang === "SD") data = await getSdDetailByNpsn(npsn);
    if (jenjang === "SMP") data = await getSmpDetailByNpsn(npsn);
    if (jenjang === "PAUD") data = await getPaudDetailByNpsn(npsn);
    if (jenjang === "PKBM") data = await getPkbmDetailByNpsn(npsn);
    if (data) writeDetailCache(jenjang, npsn, data);
  } catch {}
}

/** Prefetch modul detail (biar first render komponen detail lebih cepat di tab baru) */
async function prefetchDetailModule(jenjang) {
  try {
    if (jenjang === "SD")
      await import("@/components/schools/SchoolDetail/Sd/SchoolDetailSd");
    if (jenjang === "SMP")
      await import("@/components/schools/SchoolDetail/Smp/SchoolDetailSmp");
    if (jenjang === "PAUD")
      await import("@/components/schools/SchoolDetail/Paud/SchoolDetailPaud");
    if (jenjang === "PKBM")
      await import("@/components/schools/SchoolDetail/Pkbm/SchoolDetailPkbm");
  } catch {}
}

/* =====================================================================
   Helpers umum
===================================================================== */
const norm = (x) =>
  String(x == null ? "" : x)
    .normalize("NFKC")
    .replace(/\s+/g, " ")
    .trim();

const keyify = (x) =>
  norm(x)
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");

const isCodeLike = (v) => {
  const s = String(v || "").trim();
  if (!s) return false;
  const lower = s.toLowerCase();
  if (/^id[0-9]{6,}$/.test(lower)) return true;
  if (/^[0-9]{6,}$/.test(s)) return true;
  if (s.length > 8 && /[0-9]{6,}/.test(s)) return true;
  return false;
};

// normalisasi khusus nama kecamatan, buang awalan "KEC.", "KECAMATAN", "KAB."
const normKecamatanLabel = (x) =>
  norm(x)
    .replace(/^KEC(?:AMATAN)?\./i, "")
    .replace(/^KEC(?:AMATAN)?\s+/i, "")
    .replace(/^KAB(?:UPATEN)?\./i, "")
    .replace(/^KAB(?:UPATEN)?\s+/i, "")
    .trim();

const classifyToiletActivity = (name) => {
  const nm = String(name || "").toLowerCase();
  if (!nm.includes("toilet") && !nm.includes("jamban") && !nm.includes("wc"))
    return null;

  if (nm.includes("rehab") || nm.includes("rehabilitasi")) return "Rehab Toilet";
  if (nm.includes("pembangunan") || nm.includes("bangun"))
    return "Pembangunan Toilet";
  return "Kegiatan Toilet Lain";
};

// Normalisasi 1 row sekolah (pakai struktur mirip JSON lama dari meta)
const normalizeSchoolData = (school) => {
  let toiletBaik = 0;
  let toiletRusakSedang = 0;
  let toiletRusakBerat = 0;
  let tipe = school.type || school.status || "Tidak Diketahui";

  if (school.jenjang === "PAUD" || school.jenjang === "PKBM") {
    tipe = "Swasta";
  }

  if (school.jenjang === "SMP") {
    const teachers_toilet = school.teachers_toilet || {};
    const students_toilet = school.students_toilet || {};
    const tMale = teachers_toilet.male || {};
    const tFemale = teachers_toilet.female || {};
    const sMale = students_toilet.male || {};
    const sFemale = students_toilet.female || {};
    toiletBaik =
      (parseInt(tMale.good, 10) || 0) +
      (parseInt(tFemale.good, 10) || 0) +
      (parseInt(sMale.good, 10) || 0) +
      (parseInt(sFemale.good, 10) || 0);
    toiletRusakSedang =
      (parseInt(tMale.moderate_damage, 10) || 0) +
      (parseInt(tFemale.moderate_damage, 10) || 0) +
      (parseInt(sMale.moderate_damage, 10) || 0) +
      (parseInt(sFemale.moderate_damage, 10) || 0);
    toiletRusakBerat =
      (parseInt(tMale.heavy_damage, 10) || 0) +
      (parseInt(tFemale.heavy_damage, 10) || 0) +
      (parseInt(sMale.heavy_damage, 10) || 0) +
      (parseInt(sFemale.heavy_damage, 10) || 0);
  } else {
    const toilets = school.toilets || {};
    toiletBaik = parseInt(toilets.good, 10) || 0;
    toiletRusakSedang = parseInt(toilets.moderate_damage, 10) || 0;
    toiletRusakBerat = parseInt(toilets.heavy_damage, 10) || 0;
  }

  return {
    npsn: String(school.npsn),
    nama: school.name,
    jenjang: school.jenjang,
    tipe,
    desa: school.village,
    kecamatan: school.kecamatan,
    toiletBaik,
    toiletRusakSedang,
    toiletRusakBerat,
    totalToilet: toiletBaik + toiletRusakSedang + toiletRusakBerat,
    student_count: school.student_count == null ? 0 : school.student_count,
    originalData: school,
  };
};

/* =====================================================================
   Master lokasi dari data sekolah JSON → desa selalu ikut kecamatan
===================================================================== */

// baca nama kecamatan dari berbagai kemungkinan field di JSON
const getKecamatanFromSchool = (s) =>
  normKecamatanLabel(
    s.kecamatan ||
      s.Kecamatan ||
      s.district ||
      s.subdistrict ||
      s.kec ||
      s.Kec ||
      ""
  );

// baca nama desa dari berbagai kemungkinan field di JSON
const getDesaFromSchool = (s) =>
  norm(
    s.desa ||
      s.Desa ||
      s.village ||
      s.Village ||
      s.village_name ||
      s.villageName ||
      s.desa_kelurahan ||
      s.desaKelurahan ||
      s.Desa_Kelurahan ||
      s.desa_kel ||
      ""
  );

// Bangun master lokasi dari data sekolah (dipakai untuk JSON paud/sd/smp/pkbm)
const buildLocationMasterFromSchools = (processedSchools) => {
  const kecMap = new Map(); // key -> label
  const desaMap = new Map(); // kecKey -> Map desaKey -> label

  (processedSchools || []).forEach((s) => {
    const kLabel = getKecamatanFromSchool(s);
    if (!kLabel || isCodeLike(kLabel)) return;

    const kKey = keyify(kLabel);
    if (!kecMap.has(kKey)) kecMap.set(kKey, kLabel);

    const dLabel = getDesaFromSchool(s);
    if (!dLabel || isCodeLike(dLabel)) return;

    const dKey = keyify(dLabel);
    let dMap = desaMap.get(kKey);
    if (!dMap) {
      dMap = new Map();
      desaMap.set(kKey, dMap);
    }
    if (!dMap.has(dKey)) dMap.set(dKey, dLabel);
  });

  const kecamatanOptions = Array.from(kecMap.values()).sort((a, b) =>
    a.localeCompare(b, "id")
  );

  const desaByKecamatan = {};
  desaMap.forEach((dMap, kKey) => {
    desaByKecamatan[kKey] = Array.from(dMap.values()).sort((a, b) =>
      a.localeCompare(b, "id")
    );
  });

  return { kecamatanOptions, desaByKecamatan };
};

/* =====================================================================
   DataTable
===================================================================== */
const DataTable = memo(function DataTable({
  data,
  onDetailClick,
  onDetailPrefetch,
  onDetailModulePrefetch,
}) {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [sortField, setSortField] = useState("");
  const [sortDirection, setSortDirection] = useState("asc");

  const deferredSearchTerm = useDeferredValue(searchTerm);

  const scrollRef = React.useRef(null);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollLeft = 0;
  }, [data, deferredSearchTerm, sortField, sortDirection, currentPage, itemsPerPage]);

  const filteredData = useMemo(() => {
    let f = data || [];
    if (deferredSearchTerm) {
      const q = deferredSearchTerm.toLowerCase();
      f = f.filter(
        (s) =>
          (s.namaSekolah || "").toLowerCase().includes(q) ||
          String(s.npsn || "").includes(deferredSearchTerm) ||
          (s.kecamatan || "").toLowerCase().includes(q)
      );
    }
    if (sortField) {
      f = [...f].sort((a, b) => {
        let aVal = a[sortField];
        let bVal = b[sortField];
        if (typeof aVal === "string") {
          aVal = aVal.toLowerCase();
          bVal = bVal.toLowerCase();
        }
        if (aVal === bVal) return 0;
        return sortDirection === "asc" ? (aVal > bVal ? 1 : -1) : (aVal < bVal ? 1 : -1);
      });
    }
    return f;
  }, [data, deferredSearchTerm, sortField, sortDirection]);

  const { data: paginatedData, totalPages, totalItems } = useMemo(() => {
    const t = Math.ceil(filteredData.length / itemsPerPage);
    const s = (currentPage - 1) * itemsPerPage;
    return {
      data: filteredData.slice(s, s + itemsPerPage),
      totalPages: t > 0 ? t : 1,
      totalItems: filteredData.length,
    };
  }, [filteredData, currentPage, itemsPerPage]);

  const handleSort = (field) => {
    if (sortField === field) setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [deferredSearchTerm, itemsPerPage]);

  return (
    <div className={styles.tableContainer}>
      <div className={styles.tableControls}>
        <div className={styles.searchContainer}>
          <div className={styles.searchIcon}>🔍</div>
          <input
            type="text"
            placeholder="Cari nama sekolah, NPSN..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className={styles.searchInput}
          />
        </div>
        <div className={styles.controlGroup}>
          <label>Tampilkan:</label>
          <select
            value={itemsPerPage}
            onChange={(e) => setItemsPerPage(Number(e.target.value))}
            className={styles.itemsPerPageSelect}
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
          </select>
          <button
            onClick={() => {
              setSearchTerm("");
              setCurrentPage(1);
              setItemsPerPage(10);
              setSortField("");
              setSortDirection("asc");
            }}
            className={styles.resetTableButton}
          >
            Reset
          </button>
        </div>
      </div>

      <div className={styles.tableScrollContainer} ref={scrollRef}>
        <table className={styles.table}>
          <thead>
            <tr>
              <th>NO</th>
              <th className={styles.sortableHeader} onClick={() => handleSort("npsn")}>
                NPSN {sortField === "npsn" && (sortDirection === "asc" ? "↑" : "↓")}
              </th>
              <th className={styles.sortableHeader} onClick={() => handleSort("namaSekolah")}>
                NAMA SEKOLAH {sortField === "namaSekolah" && (sortDirection === "asc" ? "↑" : "↓")}
              </th>
              <th className={styles.sortableHeader} onClick={() => handleSort("jenjang")}>
                JENJANG {sortField === "jenjang" && (sortDirection === "asc" ? "↑" : "↓")}
              </th>
              <th>TIPE</th>
              <th>DESA</th>
              <th>KECAMATAN</th>
              <th>SISWA</th>
              <th>KLS BAIK</th>
              <th>R. SEDANG</th>
              <th>R. BERAT</th>
              <th>KURANG RKB</th>
              <th>REHAB</th>
              <th>PEMBANGUNAN</th>
              <th>DETAIL</th>
            </tr>
          </thead>
          <tbody>
            {paginatedData.length > 0 ? (
              paginatedData.map((school, index) => {
                const jenjang = String(school && school.jenjang ? school.jenjang : "").toUpperCase();
                const npsn = school ? school.npsn : null;
                return (
                  <tr
                    key={`${school.npsn ?? "n"}-${(currentPage - 1) * itemsPerPage + index}`}
                    className={styles.tableRow}
                  >
                    <td>{(currentPage - 1) * itemsPerPage + index + 1}</td>
                    <td><span className={styles.npsnBadge}>{school.npsn || "-"}</span></td>
                    <td className={styles.schoolNameCell}>{school.namaSekolah || "-"}</td>
                    <td>
                      <span
                        className={`${styles.jenjangBadge} ${
                          styles[(school.jenjang && school.jenjang.toLowerCase()) || ""]
                        }`}
                      >
                        {school.jenjang || "-"}
                      </span>
                    </td>
                    <td>{school.tipeSekolah || "-"}</td>
                    <td>{school.desa || "-"}</td>
                    <td>{school.kecamatan || "-"}</td>
                    <td><span className={styles.numberBadge}>{Number(school.student_count || 0)}</span></td>
                    <td><span className={styles.conditionGood}>{Number((school.kondisiKelas && school.kondisiKelas.baik) || 0)}</span></td>
                    <td><span className={styles.conditionModerate}>{Number((school.kondisiKelas && school.kondisiKelas.rusakSedang) || 0)}</span></td>
                    <td><span className={styles.conditionBad}>{Number((school.kondisiKelas && school.kondisiKelas.rusakBerat) || 0)}</span></td>
                    <td><span className={styles.numberBadge}>{Number(school.kurangRKB || 0)}</span></td>
                    <td><span className={styles.numberBadge}>{Number(school.rehabRuangKelas || 0)}</span></td>
                    <td><span className={styles.numberBadge}>{Number(school.pembangunanRKB || 0)}</span></td>
                    <td>
                      <button
                        className={styles.detailButton}
                        onMouseEnter={() => {
                          if (onDetailPrefetch) onDetailPrefetch(jenjang, npsn);
                          if (onDetailModulePrefetch) onDetailModulePrefetch(jenjang);
                        }}
                        onFocus={() => {
                          if (onDetailPrefetch) onDetailPrefetch(jenjang, npsn);
                          if (onDetailModulePrefetch) onDetailModulePrefetch(jenjang);
                        }}
                        onClick={() => onDetailClick && onDetailClick(school)}
                      >
                        <span className={styles.detailIcon}>👁️</span> Detail
                      </button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan="15" className={styles.noDataCell}>
                  <div className={styles.chartEmpty}>
                    <img
                      className={styles.chartEmptyIcon}
                      alt="empty"
                      src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48'%3E%3Ccircle cx='24' cy='24' r='20' fill='%23E2E8F0'/%3E%3C/svg%3E"
                    />
                    Tidak ada data
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className={styles.pagination}>
        <div className={styles.paginationInfo}>
          <span className={styles.pageInfo}>
            Menampilkan <strong>{paginatedData.length}</strong> dari <strong>{totalItems}</strong> data
          </span>
        </div>
        <div className={styles.pageButtons}>
          <button disabled={currentPage === 1} onClick={() => setCurrentPage(1)} className={styles.pageButton}>⏮️</button>
          <button disabled={currentPage === 1} onClick={() => setCurrentPage((p) => p - 1)} className={styles.pageButton}>⬅️</button>
          <span className={styles.pageIndicator}><strong>{currentPage}</strong> / {totalPages}</span>
          <button disabled={currentPage === totalPages} onClick={() => setCurrentPage((p) => p + 1)} className={styles.pageButton}>➡️</button>
          <button disabled={currentPage === totalPages} onClick={() => setCurrentPage(totalPages)} className={styles.pageButton}>⏭️</button>
        </div>
      </div>
    </div>
  );
});

/* =====================================================================
   Halaman utama
===================================================================== */
const FacilitiesPage = () => {
  const [currentView, setCurrentView] = useState("main");
  const [selectedSchool, setSelectedSchool] = useState(null);

  const [searchQuery, setSearchQuery] = useState("");
  const deferredSearchQuery = useDeferredValue(searchQuery);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [selectedJenjang, setSelectedJenjang] = useState("Semua Jenjang");
  const [selectedKecamatan, setSelectedKecamatan] = useState("Semua Kecamatan");
  const [selectedDesa, setSelectedDesa] = useState("Semua Desa");

  const [schoolData, setSchoolData] = useState([]);
  const [kegiatanData, setKegiatanData] = useState([]);
  const [filteredSchoolData, setFilteredSchoolData] = useState([]);
  const [kecamatanOptions, setKecamatanOptions] = useState([]);
  const [desaByKecamatan, setDesaByKecamatan] = useState({});

  const [kondisiPieData, setKondisiPieData] = useState([]);
  const [rehabilitasiPieData, setRehabilitasiPieData] = useState([]);
  const [pembangunanPieData, setPembangunanPieData] = useState([]);
  const [kondisiToiletData, setKondisiToiletData] = useState([]);
  const [intervensiToiletData, setIntervensiToiletData] = useState([]);

  // Search (pakai deferred value)
  const performSearch = (data) => {
    const qRaw = (deferredSearchQuery || "").trim();
    if (!qRaw) return data;
    const q = qRaw.toLowerCase();
    return data.filter(
      (s) =>
        (s.nama || "").toLowerCase().includes(q) ||
        (s.npsn || "").toLowerCase().includes(q) ||
        (s.jenjang || "").toLowerCase().includes(q) ||
        (s.kecamatan || "").toLowerCase().includes(q) ||
        (s.desa || "").toLowerCase().includes(q)
    );
  };

  // INIT → fetch dari Supabase RPC + JSON (kecamatan & desa MURNI dari JSON)
  useEffect(() => {
    let cancelled = false;

    const initializeData = async () => {
      setLoading(true);
      setError(null);

      try {
        const urls = {
          paud: "https://peta-sekolah.vercel.app/paud/data/paud.json",
          sd: "https://peta-sekolah.vercel.app/sd/data/sd_new.json",
          smp: "https://peta-sekolah.vercel.app/smp/data/smp.json",
          pkbm: "https://peta-sekolah.vercel.app/pkbm/data/pkbm.json",
          kecamatan: "https://peta-sekolah.vercel.app/data/kecamatan.geojson",
        };

        const [
          schoolsRpcRes,
          projectsRpcRes,
          paudJson,
          sdJson,
          smpJson,
          pkbmJson,
          kecamatanGeoJson,
        ] = await Promise.all([
          rpcFirstAvailable(RPC_TOILET_SCHOOLS_CANDIDATES, {}),
          rpcFirstAvailable(RPC_TOILET_PROJECTS_CANDIDATES, {}),
          fetch(urls.paud).then((res) => res.json()).catch(() => null),
          fetch(urls.sd).then((res) => res.json()).catch(() => null),
          fetch(urls.smp).then((res) => res.json()).catch(() => null),
          fetch(urls.pkbm).then((res) => res.json()).catch(() => null),
          fetch(urls.kecamatan).then((res) => res.json()).catch(() => null),
        ]);

        if (cancelled) return;

        // schools RPC bisa mengembalikan array langsung atau object {schools: [...]}
        const schoolsRpcDataRaw = schoolsRpcRes?.data;
        const schoolsRpcRows = Array.isArray(schoolsRpcDataRaw)
          ? schoolsRpcDataRaw
          : Array.isArray(schoolsRpcDataRaw?.schools)
            ? schoolsRpcDataRaw.schools
            : [];

        // projects RPC bisa mengembalikan array langsung atau object {projects: [...]}
        const projectsRpcDataRaw = projectsRpcRes?.data;
        const projectsRpcRows = Array.isArray(projectsRpcDataRaw)
          ? projectsRpcDataRaw
          : Array.isArray(projectsRpcDataRaw?.projects)
            ? projectsRpcDataRaw.projects
            : [];

        const allRawData = (schoolsRpcRows || []).map((row) =>
          mapRpcSchoolRowToLegacyShape(row)
        );

        const allProcessedData = allRawData.map(normalizeSchoolData);
        setSchoolData(allProcessedData);

        const allKegiatanData = (projectsRpcRows || []).map((p) => ({
          Kegiatan: pickFirst(p, ["activity_name", "kegiatan", "Kegiatan"], ""),
          Lokal: pickFirst(p, ["volume", "nilai", "Lokal"], null),
          school_id: pickFirst(p, ["school_id"], null),
          npsn: pickFirst(p, ["npsn"], null),
        }));
        setKegiatanData(allKegiatanData);

        // ===== MASTER LOKASI DARI JSON (PAUD/SD/SMP/PKBM + kecamatan.geojson) =====
        const flattenSchoolData = (dataByKecamatan) => {
          if (!dataByKecamatan) return [];
          return Object.entries(dataByKecamatan).flatMap(
            ([kecamatanName, schools]) =>
              (schools || []).map((school) => ({
                ...school,
                kecamatan: kecamatanName,
              }))
          );
        };

        const jsonSchools = [
          ...flattenSchoolData(paudJson),
          ...flattenSchoolData(sdJson),
          ...flattenSchoolData(smpJson),
          ...flattenSchoolData(pkbmJson),
        ];

        const { kecamatanOptions: kecFromJson, desaByKecamatan } =
          buildLocationMasterFromSchools(jsonSchools);

        // desa murni dari JSON
        setDesaByKecamatan(desaByKecamatan || {});

        // kecamatan dari geojson (42 lengkap), fallback ke JSON kalau gagal
        let finalKecamatanOptions = [];
        if (kecamatanGeoJson && Array.isArray(kecamatanGeoJson.features)) {
          const allDistricts = kecamatanGeoJson.features
            .map((feature) => feature.properties && feature.properties.district)
            .filter(Boolean)
            .map(normKecamatanLabel);

          const uniqueDistricts = [...new Set(allDistricts)].sort((a, b) =>
            a.localeCompare(b, "id")
          );
          finalKecamatanOptions = uniqueDistricts;
        } else {
          finalKecamatanOptions = kecFromJson || [];
        }
        setKecamatanOptions(finalKecamatanOptions);

        setLoading(false);
      } catch (e) {
        if (!cancelled) {
          const msg = e?.message ? e.message : String(e);
          setError(`Failed to load data: ${msg}`);
          setLoading(false);
        }
      }
    };

    initializeData();

    // Idle: prefetch chunk ChartsSection biar cepat saat muncul
    if (typeof window !== "undefined") {
      if ("requestIdleCallback" in window) {
        window.requestIdleCallback(() => {
          import("./ChartsSection").catch(() => {});
        }, { timeout: 1500 });
      } else {
        setTimeout(() => import("./ChartsSection").catch(() => {}), 0);
      }
    }

    return () => {
      cancelled = true;
    };
  }, []);

  // Refilter + charts (non-blocking biar UI halus)
  useEffect(() => {
    if (schoolData.length === 0) return;

    startTransition(() => {
      // 1) filter + search
      let filtered = schoolData;
      if (selectedJenjang !== "Semua Jenjang")
        filtered = filtered.filter((s) => s.jenjang === selectedJenjang);

      if (selectedKecamatan !== "Semua Kecamatan")
        filtered = filtered.filter(
          (s) =>
            normKecamatanLabel(s.kecamatan || "") ===
            normKecamatanLabel(selectedKecamatan || "")
        );

      if (selectedDesa !== "Semua Desa")
        filtered = filtered.filter((s) => s.desa === selectedDesa);

      filtered = performSearch(filtered);
      setFilteredSchoolData(filtered);

      // 2) hitung chart setelah render tabel → tanpa jank
      queueMicrotask(() => {
        const t0 =
          typeof performance !== "undefined" && performance.now
            ? performance.now()
            : Date.now();
        generateChartData(filtered, schoolData, kegiatanData);
        const t1 =
          typeof performance !== "undefined" && performance.now
            ? performance.now()
            : Date.now();
        if (process.env.NODE_ENV !== "production") {
          // eslint-disable-next-line no-console
          console.log(
            `[Perf] generateChartData ${(t1 - t0).toFixed(
              1
            )}ms • sample=${filtered && filtered.length ? filtered.length : 0}`
          );
        }
      });
    });
  }, [
    schoolData,
    kegiatanData,
    selectedJenjang,
    selectedKecamatan,
    selectedDesa,
    deferredSearchQuery,
  ]);

  const resetAllFilters = () => {
    setSelectedJenjang("Semua Jenjang");
    setSelectedKecamatan("Semua Kecamatan");
    setSelectedDesa("Semua Desa");
    setSearchQuery("");
  };

  // label/tooltip pie & bar
  const renderLabelInside = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
    actualCount,
  }) => {
    if (!actualCount) return null;
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={11}
        fontWeight="bold"
      >
        <tspan x={x} dy="-0.3em">{`${percent.toFixed(1)}%`}</tspan>
        <tspan x={x} dy="1.2em">
          ({actualCount})
        </tspan>
      </text>
    );
  };

  const customPieTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      const p = data && data.payload ? data.payload : null;
      if (!p || p.percent === undefined) return null;
      return (
        <div className={styles.customTooltip}>
          <div className={styles.tooltipContent}>
            <span className={styles.tooltipLabel}>{p.name}</span>
            <span className={styles.tooltipValue}>
              {p.actualCount} unit ({p.percent.toFixed(1)}%)
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  const customBarTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className={styles.customTooltip}>
          <div className={styles.tooltipContent}>
            <span className={styles.tooltipLabel}>{label}</span>
            <span className={styles.tooltipValue}>
              {payload[0].value} unit
            </span>
          </div>
        </div>
      );
    }
    return null;
  };

  // Generate charts
  const generateChartData = (data, allSchoolData, allKegiatanData) => {
    const pembangunanDilakukan = (allKegiatanData || []).filter(
      (k) => classifyToiletActivity(k.Kegiatan) === "Pembangunan Toilet"
    ).length;
    const rehabDilakukan = (allKegiatanData || []).filter(
      (k) => classifyToiletActivity(k.Kegiatan) === "Rehab Toilet"
    ).length;

    const sekolahTanpaToilet = (allSchoolData || []).filter(
      (s) => s.totalToilet === 0
    ).length;
    const kebutuhanRehabilitasi = (allSchoolData || []).filter(
      (s) => s.toiletRusakBerat > 0
    ).length;

    const rekap = {
      sekolah_tanpa_toilet: sekolahTanpaToilet,
      pembangunan_dilakukan: pembangunanDilakukan,
      kebutuhan_rehabilitasi: kebutuhanRehabilitasi,
      rehab_dilakukan: rehabDilakukan,
      intervensi_pembangunan: pembangunanDilakukan,
      intervensi_rehab: rehabDilakukan,
    };

    const kebutuhan_belum_dibangun =
      rekap.sekolah_tanpa_toilet - rekap.pembangunan_dilakukan;

    const pieDataMapper = (d) => ({ ...d, actualCount: d.value });

    const totalPembangunan = rekap.sekolah_tanpa_toilet || 1;
    setPembangunanPieData(
      [
        {
          name: "Kebutuhan Toilet (Belum dibangun)",
          value: Math.max(0, kebutuhan_belum_dibangun),
          percent:
            (Math.max(0, kebutuhan_belum_dibangun) / totalPembangunan) * 100,
          color: "#FF6B6B",
        },
        {
          name: "Pembangunan dilakukan",
          value: rekap.pembangunan_dilakukan,
          percent:
            (rekap.pembangunan_dilakukan / totalPembangunan) * 100,
          color: "#4ECDC4",
        },
      ].map(pieDataMapper)
    );

    const totalRehabilitasi =
      (rekap.kebutuhan_rehabilitasi + rekap.rehab_dilakukan) || 1;
    setRehabilitasiPieData(
      [
        {
          name: "Rusak Berat (Belum Direhab)",
          value: rekap.kebutuhan_rehabilitasi,
          percent:
            (rekap.kebutuhan_rehabilitasi / totalRehabilitasi) * 100,
          color: "#FF6B6B",
        },
        {
          name: "Rehab Dilakukan",
          value: rekap.rehab_dilakukan,
          percent:
            (rekap.rehab_dilakukan / totalRehabilitasi) * 100,
          color: "#4ECDC4",
        },
      ]
        .filter((d) => d.value > 0)
        .map(pieDataMapper)
    );

    setIntervensiToiletData([
      {
        name: "Total Intervensi",
        value:
          rekap.intervensi_pembangunan + rekap.intervensi_rehab,
        color: "#667eea",
      },
      {
        name: "Pembangunan Toilet",
        value: rekap.intervensi_pembangunan,
        color: "#4ECDC4",
      },
      {
        name: "Rehab Toilet",
        value: rekap.intervensi_rehab,
        color: "#FFD93D",
      },
    ]);

    let totalToiletBaik = 0;
    let totalToiletRusakSedang = 0;
    let totalToiletRusakBerat = 0;
    data.forEach((s) => {
      totalToiletBaik += s.toiletBaik;
      totalToiletRusakSedang += s.toiletRusakSedang;
      totalToiletRusakBerat += s.toiletRusakBerat;
    });
    const totalToiletCount =
      totalToiletBaik + totalToiletRusakSedang + totalToiletRusakBerat;

    setKondisiToiletData([
      { name: "Total Unit", value: totalToiletCount, color: "#667eea" },
      { name: "Unit Baik", value: totalToiletBaik, color: "#4ECDC4" },
      {
        name: "Unit Rusak Sedang",
        value: totalToiletRusakSedang,
        color: "#FFD93D",
      },
      {
        name: "Unit Rusak Berat",
        value: totalToiletRusakBerat,
        color: "#FF6B6B",
      },
      {
        name: "Sekolah Tanpa Toilet",
        value: data.filter((s) => s.totalToilet === 0).length,
        color: "#ff8787",
      },
    ]);

    if (totalToiletCount > 0) {
      setKondisiPieData(
        [
          {
            name: "Baik",
            value: totalToiletBaik,
            percent:
              (totalToiletBaik / totalToiletCount) * 100,
            color: "#4ECDC4",
          },
          {
            name: "Rusak Sedang",
            value: totalToiletRusakSedang,
            percent:
              (totalToiletRusakSedang / totalToiletCount) * 100,
            color: "#FFD93D",
          },
          {
            name: "Rusak Berat",
            value: totalToiletRusakBerat,
            percent:
              (totalToiletRusakBerat / totalToiletCount) * 100,
            color: "#FF6B6B",
          },
        ].map(pieDataMapper)
      );
    } else {
      setKondisiPieData([
        {
          name: "Tidak Ada Data",
          value: 1,
          actualCount: 0,
          percent: 100,
          color: "#95A5A6",
        },
      ]);
    }
  };

  // data tabel
  const mappedTableData = useMemo(() => {
    return (filteredSchoolData || []).map((s) => ({
      npsn: s.npsn,
      namaSekolah: s.nama,
      jenjang: s.jenjang,
      tipeSekolah: s.tipe,
      desa: s.desa,
      kecamatan: s.kecamatan,
      student_count: Number(s.student_count || 0),
      kondisiKelas: {
        baik: Number(s.toiletBaik || 0),
        rusakSedang: Number(s.toiletRusakSedang || 0),
        rusakBerat: Number(s.toiletRusakBerat || 0),
      },
      kurangRKB: 0,
      rehabRuangKelas: 0,
      pembangunanRKB: 0,
    }));
  }, [filteredSchoolData]);

  const handleDetailClickNavigate = useCallback((row) => {
    const npsn = row && row.npsn ? row.npsn : null;
    const jenjang = String(row && row.jenjang ? row.jenjang : "").toUpperCase();
    if (!npsn) {
      alert("NPSN sekolah tidak ditemukan.");
      return;
    }
    let url = `/detail-sekolah?npsn=${encodeURIComponent(
      npsn
    )}&jenjang=${encodeURIComponent(jenjang)}`;
    if (jenjang === "PAUD")
      url = `/paud/school_detail?npsn=${encodeURIComponent(npsn)}`;
    if (jenjang === "SD")
      url = `/sd/school_detail?npsn=${encodeURIComponent(npsn)}`;
    if (jenjang === "SMP")
      url = `/smp/school_detail?npsn=${encodeURIComponent(npsn)}`;
    if (jenjang === "PKBM")
      url = `/pkbm/school_detail?npsn=${encodeURIComponent(npsn)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  }, []);

  const handlePrefetchDetail = useCallback((jenjang, npsn) => {
    prefetchDetailByNpsn(jenjang, npsn);
  }, []);

  const handlePrefetchModule = useCallback((jenjang) => {
    prefetchDetailModule(jenjang);
  }, []);

  // FILTER BAR (inline)
  const jenjangOptions = ["Semua Jenjang", "PAUD", "SD", "SMP", "PKBM"];

  // Desa mengikuti kecamatan, key-nya pakai normKecamatanLabel supaya cocok
  const desaOptionsFiltered = useMemo(() => {
    if (selectedKecamatan === "Semua Kecamatan") return ["Semua Desa"];
    const key = keyify(normKecamatanLabel(selectedKecamatan || ""));
    const list = desaByKecamatan[key] || [];
    return ["Semua Desa", ...list];
  }, [selectedKecamatan, desaByKecamatan]);

  const FiltersBar = () => (
    <section className={`${styles.card} ${styles.filtersCard || ""}`}>
      <header className={styles.cardHeader}>
        <h2>Filter Data</h2>
      </header>
      <div
        style={{
          display: "grid",
          gap: 12,
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          alignItems: "end",
        }}
      >
        <div>
          <label style={{ display: "block", fontSize: 12, marginBottom: 6 }}>
            Filter Jenjang
          </label>
          <select
            value={selectedJenjang}
            onChange={(e) => setSelectedJenjang(e.target.value)}
            className={styles.itemsPerPageSelect}
            style={{ width: "100%" }}
          >
            {jenjangOptions.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: 12, marginBottom: 6 }}>
            Filter Kecamatan
          </label>
          <select
            value={selectedKecamatan}
            onChange={(e) => {
              setSelectedKecamatan(e.target.value);
              setSelectedDesa("Semua Desa");
            }}
            className={styles.itemsPerPageSelect}
            style={{ width: "100%" }}
          >
            {["Semua Kecamatan", ...kecamatanOptions].map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: 12, marginBottom: 6 }}>
            Filter Desa
          </label>
          <select
            value={selectedDesa}
            onChange={(e) => setSelectedDesa(e.target.value)}
            className={styles.itemsPerPageSelect}
            style={{ width: "100%" }}
            disabled={selectedKecamatan === "Semua Kecamatan"}
          >
            {desaOptionsFiltered.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label style={{ display: "block", fontSize: 12, marginBottom: 6 }}>
            Pencarian Cepat
          </label>
          <input
            type="text"
            placeholder="Cari nama sekolah / NPSN / desa / kecamatan…"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
            style={{ width: "100%" }}
          />
        </div>

        <div>
          <button
            onClick={resetAllFilters}
            className={styles.resetTableButton}
            style={{ width: "100%", marginTop: 6 }}
          >
            Reset Semua Filter
          </button>
        </div>
      </div>
    </section>
  );

  // Helper aman (gantikan IIFE+switch yang bikin parser rewel)
  const renderDetailSection = () => {
    if (!(currentView === "detail" && selectedSchool)) return null;

    const jenjang = selectedSchool.jenjang;
    let DetailComponent = null;
    if (jenjang === "PAUD") DetailComponent = SchoolDetailPaud;
    else if (jenjang === "SD") DetailComponent = SchoolDetailSd;
    else if (jenjang === "SMP") DetailComponent = SchoolDetailSmp;
    else if (jenjang === "PKBM") DetailComponent = SchoolDetailPkbm;

    return (
      <Suspense fallback={<div style={{ padding: 16 }}>Memuat detail…</div>}>
        {DetailComponent ? (
          <DetailComponent
            schoolData={{
              ...(selectedSchool.originalData || {}),
              kecamatan: selectedSchool.kecamatan,
            }}
          />
        ) : (
          <div className={styles.container}>
            <div className={styles.card}>
              <h2>Detail tidak tersedia</h2>
            </div>
          </div>
        )}
      </Suspense>
    );
  };

  const renderMainView = () => {
    if (loading) {
      return (
        <div className={styles.container}>
          <div className={styles.card}>
            <div className={styles.loadingContainer}>
              <div className={styles.loadingSpinner}></div>
              <p className={styles.loadingText}>Memuat data sekolah...</p>
            </div>
          </div>
        </div>
      );
    }

    if (error) {
      return (
        <div className={styles.container}>
          <div className={styles.card}>
            <div className={styles.errorContainer}>
              <div className={styles.errorIcon}>⚠️</div>
              <h3>Terjadi Kesalahan</h3>
              <p className={styles.errorMessage}>{error}</p>
              <button
                className={styles.retryButton}
                onClick={() => window.location.reload()}
              >
                Muat Ulang Halaman
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className={styles.container}>
        <header className={`${styles.card} ${styles.pageHeader}`}>
          <div className={styles.headerContent}>
            <h1 className={styles.pageTitle}>
              Dashboard Fasilitas Toilet Sekolah
            </h1>
            <p className={styles.pageSubtitle}>
              Analisis kondisi dan kebutuhan toilet sekolah di wilayah kerja
            </p>
          </div>
        </header>

        {/* FILTER BAR */}
        <FiltersBar />

        {/* CHARTS */}
        <ErrorBoundary>
          <Suspense
            fallback={
              <section className={styles.chartsSection}>
                <div className={styles.pieChartsGrid}>
                  <div className={`${styles.card} ${styles.chartCard}`}>
                    <header className={styles.chartHeader}>
                      <h3>Kondisi Unit Toilet</h3>
                    </header>
                    <div className={styles.chartWrapper}>
                      <ChartSkeleton height={280} />
                    </div>
                  </div>
                  <div className={`${styles.card} ${styles.chartCard}`}>
                    <header className={styles.chartHeader}>
                      <h3>Status Rehabilitasi</h3>
                    </header>
                    <div className={styles.chartWrapper}>
                      <ChartSkeleton height={280} />
                    </div>
                  </div>
                  <div className={`${styles.card} ${styles.chartCard}`}>
                    <header className={styles.chartHeader}>
                      <h3>Status Pembangunan</h3>
                    </header>
                    <div className={styles.chartWrapper}>
                      <ChartSkeleton height={280} />
                    </div>
                  </div>
                </div>
                <div className={styles.barChartsGrid}>
                  <div className={`${styles.card} ${styles.chartCard}`}>
                    <header className={styles.chartHeader}>
                      <h3>Kondisi Unit Toilet</h3>
                    </header>
                    <div className={styles.chartWrapper}>
                      <ChartSkeleton height={320} />
                    </div>
                  </div>
                  <div className={`${styles.card} ${styles.chartCard}`}>
                    <header className={styles.chartHeader}>
                      <h3>Kategori Intervensi</h3>
                    </header>
                    <div className={styles.chartWrapper}>
                      <ChartSkeleton height={320} />
                    </div>
                  </div>
                </div>
              </section>
            }
          >
            <ChartsSection
              kondisiPieData={kondisiPieData}
              rehabilitasiPieData={rehabilitasiPieData}
              pembangunanPieData={pembangunanPieData}
              kondisiToiletData={kondisiToiletData}
              intervensiToiletData={intervensiToiletData}
              customPieTooltip={customPieTooltip}
              customBarTooltip={customBarTooltip}
              renderLabelInside={renderLabelInside}
            />
          </Suspense>
        </ErrorBoundary>

        {/* TABLE */}
        <section className={`${styles.card} ${styles.tableCard}`}>
          <header className={styles.cardHeader}>
            <div className={styles.tableHeaderContent}>
              <h2>Data Sekolah</h2>
            </div>
          </header>

          <div className={styles.chartContent}>
            <DataTable
              data={mappedTableData}
              onDetailClick={handleDetailClickNavigate}
              onDetailPrefetch={handlePrefetchDetail}
              onDetailModulePrefetch={handlePrefetchModule}
            />
          </div>
        </section>
      </div>
    );
  };

  return (
    <main className={styles.pageWrapper}>
      {currentView === "main" && renderMainView()}
      {renderDetailSection()}
    </main>
  );
};

export default FacilitiesPage;
