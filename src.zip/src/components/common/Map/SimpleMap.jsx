import React, { useEffect, useMemo, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, ZoomControl } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import styles from "./SimpleMap.module.css";
import {
  applyFilters,
  makeKecamatanNumberIcon,
  getLatLngSafe,
  kecKey,
  uniqueBy,
  GARUT_LEAFLET_BOUNDS,
} from "./mapUtils";

const GARUT_CENTER = [-7.214, 107.903];
const GARUT_ZOOM = 10;
const SCHOOL_MARKER_ZOOM = 12;

function colorForKey(key) {
  const palette = [
    "#1e40af","#7c3aed","#d946ef","#f59e0b","#10b981","#06b6d4",
    "#3b82f6","#ec4899","#f97316","#0ea5e9","#eab308","#ef4444",
    "#14b8a6","#a855f7","#8b5cf6","#f43f5e","#06b6d4","#84cc16",
    "#6366f1","#fb923c","#ec4899","#10b981","#f97316","#3b82f6"
  ];
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return palette[h % palette.length];
}
const colorForJenjang = (j) => {
  const s = (j || "").toString().toUpperCase();
  if (s.includes("PAUD")) return "#f59e0b";
  if (s === "SD")        return "#3b82f6";
  if (s === "SMP")       return "#10b981";
  if (s.includes("PKBM"))return "#ef4444";
  return "#6366f1";
};

export default function SimpleMap({
  schools = [],
  initialCenter = GARUT_CENTER,
  initialZoom = GARUT_ZOOM,
  filters = {},
  statsOverride,
  kecamatanGeo,
  desaGeo,
  onZoomChange, // [NEW] opsional: callback(z) → Map.jsx bisa tau kapan z >= 12
}) {
  const mapRef = useRef(null);
  const fitTimer = useRef(null);

  const kabLayerRef = useRef(null);
  const kecLayerRef = useRef(null);
  const labelLayerRef = useRef(null);
  const schoolLayerRef = useRef(null);

  const [zoom, setZoom] = useState(initialZoom);
  const showSchoolDots = zoom >= SCHOOL_MARKER_ZOOM;

  const schoolsUnique = useMemo(
    () =>
      uniqueBy(schools, (s) => {
        if (!s) return null;
        const npsn = (s?.npsn || s?.NPSN || "").toString().trim();
        if (npsn && npsn !== "undefined" && npsn !== "null") return "NPSN:" + npsn;
        const name = (s?.namaSekolah || s?.name || "").toString().trim().toUpperCase();
        const desa = (s?.desa || s?.village || "").toString().trim().toUpperCase();
        const kk  = kecKey(s?.kecamatan || "");
        return name + "::" + desa + "::" + kk;
      }),
    [schools]
  );

  const filtered = useMemo(() => applyFilters(schoolsUnique, filters), [schoolsUnique, filters]);

  const kecRekap = useMemo(() => {
    const group = new Map();
    for (const s of filtered) {
      const kk = kecKey(s?.kecamatan);
      if (!kk) continue;
      if (!group.has(kk)) group.set(kk, { k: kk, displayName: s?.kecamatan || kk, total: 0, coords: [] });
      const g = group.get(kk);
      g.total += 1;
      const ll = getLatLngSafe(s);
      if (ll) g.coords.push(ll);
    }
    return Array.from(group.values()).map((g) => {
      let center = [-7.214, 107.903];
      if (g.coords.length) {
        const sum = g.coords.reduce((acc, cur) => [acc[0] + cur[0], acc[1] + cur[1]], [0, 0]);
        center = [sum[0] / g.coords.length, sum[1] / g.coords.length];
      }
      return { kecKey: g.k, displayName: g.displayName, total: g.total, center };
    });
  }, [filtered]);

  const badgeKecamatan =
    statsOverride?.kecamatanCount != null ? statsOverride.kecamatanCount : kecRekap.length;
  const badgeSekolah =
    statsOverride?.sekolahCount != null ? statsOverride.sekolahCount : filtered.length;

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (!kabLayerRef.current) kabLayerRef.current = L.layerGroup().addTo(map);
    else kabLayerRef.current.clearLayers();
    if (!kecLayerRef.current) kecLayerRef.current = L.layerGroup().addTo(map);
    else kecLayerRef.current.clearLayers();
    if (!labelLayerRef.current) labelLayerRef.current = L.layerGroup().addTo(map);
    else labelLayerRef.current.clearLayers();

    const drawKecamatanFromLocal = (geo) => {
      try {
        const feats = Array.isArray(geo?.features) ? geo.features : [];
        for (const f of feats) {
          const p = f?.properties || {};
          const rawName =
            p.name || p.Name || p.kecamatan || p.Kecamatan || p.NAMKEC || p.NAMKec || p.NAMOBJ || "";
          const kk = kecKey(rawName);
          const gj = L.geoJSON(f, {
            style: {
              fillColor: colorForKey(kk),
              fillOpacity: 0.85,
              color: "#ffffff",
              weight: 2.5,
              opacity: 0.9,
            },
            interactive: false,
          });
          gj.addTo(kecLayerRef.current);
          const c = gj.getBounds().getCenter();
          L.marker(c, {
            interactive: false,
            icon: L.divIcon({ className: styles.kecLabel, html: `<div>${rawName}</div>` }),
            zIndexOffset: 800,
          }).addTo(labelLayerRef.current);
        }
        const allBounds = kecLayerRef.current.getBounds();
        if (allBounds && allBounds.isValid()) {
          map.fitBounds(allBounds.pad(0.05), { animate: true });
        }
      } catch {}
    };

    if (kecamatanGeo && Array.isArray(kecamatanGeo?.features)) {
      drawKecamatanFromLocal(kecamatanGeo);
      return () => {
        kabLayerRef.current?.clearLayers();
        kecLayerRef.current?.clearLayers();
        labelLayerRef.current?.clearLayers();
      };
    }

    // Fallback Overpass sengaja dipertahankan (sama seperti sebelumnya) — dipotong di sini demi ringkas

  }, [kecamatanGeo]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const doFit = () => {
      const pts = kecRekap.map((k) => k.center).filter(Boolean);
      if (!pts.length) {
        map.setView(L.latLng(GARUT_CENTER[0], GARUT_CENTER[1]), initialZoom, { animate: true });
        return;
      }
      if (pts.length === 1) {
        map.setView(L.latLng(pts[0][0], pts[0][1]), Math.max(initialZoom, 12), { animate: true });
        return;
      }
      const bounds = L.latLngBounds(pts.map((p) => L.latLng(p[0], p[1])));
      map.fitBounds(bounds.pad(0.12), { animate: true });
    };
    clearTimeout(fitTimer.current);
    fitTimer.current = setTimeout(doFit, 160);
    return () => clearTimeout(fitTimer.current);
  }, [kecRekap, initialZoom]);

  // Titik sekolah (canvas) pada zoom tinggi — (kode sama seperti versi sebelumnya)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!schoolLayerRef.current) {
      schoolLayerRef.current = L.layerGroup(undefined, { pane: "overlayPane" }).addTo(map);
    } else {
      schoolLayerRef.current.clearLayers();
    }
    if (!showSchoolDots) return;

    const pts = [];
    for (const s of filtered) {
      const ll = getLatLngSafe(s);
      if (!ll) continue;
      pts.push({ ll, j: s?.jenjang, name: s?.namaSekolah || s?.name || "", k: s?.kecamatan || "" });
    }
    for (const p of pts) {
      const c = L.circleMarker(p.ll, {
        radius: 4.5,
        fillColor: colorForJenjang(p.j),
        color: "#ffffff",
        weight: 0.7,
        fillOpacity: 0.95,
        pane: "overlayPane",
      });
      c.addTo(schoolLayerRef.current);
      c.bindPopup(
        `<div class="${styles.popup}">
           <div class="${styles.popupTitle}">${p.name}</div>
           <div class="${styles.popupCounts}">${p.k}</div>
         </div>`
      );
    }
    return () => schoolLayerRef.current?.clearLayers();
  }, [filtered, showSchoolDots]);

  // [NEW] expose perubahan zoom ke parent
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const handleZoom = () => {
      const z = map.getZoom();
      setZoom(z);
      if (typeof onZoomChange === "function") onZoomChange(z);
    };
    map.on("zoomend", handleZoom);
    // sync awal
    const z0 = map.getZoom();
    setZoom(z0);
    if (typeof onZoomChange === "function") onZoomChange(z0);
    return () => map.off("zoomend", handleZoom);
  }, [onZoomChange]);

  return (
    <div className={styles.mapRoot}>
      <div className={styles.filterBar}>
        <div className={styles.countBadge}>
          {statsOverride?.kecamatanCount ?? kecRekap.length} kecamatan • {statsOverride?.sekolahCount ?? filtered.length} sekolah
        </div>
      </div>

      <MapContainer
        ref={mapRef}
        center={initialCenter}
        zoom={initialZoom}
        className={styles.map}
        whenCreated={(m) => { mapRef.current = m; }}
        preferCanvas
        inertia={false}
        updateWhenZooming={false}
        updateWhenIdle
        keepBuffer={2}
        scrollWheelZoom={false}
        zoomControl={false}
        maxBounds={GARUT_LEAFLET_BOUNDS}
        maxBoundsViscosity={0.95}
        attributionControl={false}
      >
        <ZoomControl position="bottomright" />
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" detectRetina />
        {!showSchoolDots && kecRekap.map((kec) => {
          const icon = makeKecamatanNumberIcon(kec.total, "", styles);
          return (
            <Marker key={kec.kecKey} position={kec.center} icon={icon}>
              <Popup>
                <div className={styles.popup}>
                  <div className={styles.popupTitle}>{kec.displayName}</div>
                  <div className={styles.popupCounts}>{kec.total} sekolah</div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}
