import React from 'react';

export default function MapBox({ children }) {
  return <div className="u-map-box">{children}</div>;
}
