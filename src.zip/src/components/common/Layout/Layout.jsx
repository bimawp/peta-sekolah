import React, { useEffect, useState, Suspense } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "../Sidebar/Sidebar";
import Header from "../Header/Header";
import styles from "./Layout.module.css";
import SuspenseLoader from "../SuspenseLoader/SuspenseLoader";
import { useIdlePrefetch } from "@/hooks/useIdlePrefetch";

const Layout = () => {
  // Header kamu butuh tahu state sidebar? Kalau tidak, aman dihapus.
  // Di sini kita tetap simpan agar kompatibel.
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const toggleSidebar = () => setIsSidebarOpen((v) => !v);

  const idlePrefetch = useIdlePrefetch();

  // Prefetch ringan saat idle (chunk + JSON yang sering dipakai)
  useEffect(() => {
    idlePrefetch([
      { type: "chunk", importer: () => import("@/pages/Map/Map.jsx") },
      { type: "chunk", importer: () => import("@/pages/Facilities/FacilitiesPage.jsx") },
      { type: "chunk", importer: () => import("@/pages/Dashboard/Dashboard.jsx") },
      { type: "json", url: "/data/kecamatan.geojson" },
      { type: "json", url: "/data/desa.geojson" },
      { type: "json", url: "/data/sd_new.json" },
      { type: "json", url: "/data/smp.json" },
      { type: "json", url: "/data/paud.json" },
      { type: "json", url: "/data/pkbm.json" },
      { type: "json", url: "/data/data_kegiatan_sd.json" },
      { type: "json", url: "/data/data_kegiatan_smp.json" },
      { type: "json", url: "/data/data_kegiatan_paud.json" },
      { type: "json", url: "/data/data_kegiatan_pkbm.json" },
    ]);
  }, [idlePrefetch]);

  return (
    <div className={styles.layout}>
      {/* PAKAI Sidebar kamu apa adanya (tanpa props). */}
      <Sidebar />

      <div
        className={`${styles.mainContent} ${isSidebarOpen ? "" : styles.mainContentCollapsed}`}
        data-scroll-stable
      >
        <Header toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen} />

        {/* Suspense lokal → header/sidebar tetap kelihatan saat halaman lazy-load */}
        <main className={styles.contentArea}>
          <Suspense fallback={<SuspenseLoader />}>
            <Outlet />
          </Suspense>
        </main>
      </div>
    </div>
  );
};

export default Layout;
