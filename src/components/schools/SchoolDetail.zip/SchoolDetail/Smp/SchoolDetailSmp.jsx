import React from "react";
import styles from "./SchoolDetailSmp.module.css";

const getData = (data, path, defaultValue = 0) => {
  const value = path.reduce(
    (obj, key) => (obj && obj[key] != null ? obj[key] : undefined),
    data
  );
  if (value === 0 || value === 0.0) return 0;
  return value ?? defaultValue;
};

const findOwnershipStatus = (obj, defaultValue = "-") => {
  if (!obj) return defaultValue;
  for (const key in obj) {
    if (obj[key] === "Ya" || obj[key] === "YA") {
      return key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ");
    }
  }
  return defaultValue;
};

// Normalisasi room object dari meta.prasarana.*
// meta biasanya punya: good, moderate_damage, heavy_damage, total (atau total_all)
const normalizeRoom = (src) => {
  const o = src && typeof src === "object" ? src : {};
  const good = Number(o.good ?? o.classrooms_good ?? o.baik ?? 0);
  const moderate = Number(
    o.moderate_damage ??
      o.classrooms_moderate_damage ??
      o.rusak_sedang ??
      o.rusakSedang ??
      0
  );
  const heavy = Number(
    o.heavy_damage ??
      o.classrooms_heavy_damage ??
      o.rusak_berat ??
      o.rusakBerat ??
      0
  );
  const totalAll = Number(o.total_all ?? o.total ?? o.total_room ?? 0);
  const totalMh = Number(o.total_mh ?? (moderate + heavy));
  return {
    good,
    moderate_damage: moderate,
    heavy_damage: heavy,
    total_all: totalAll,
    total_mh: totalMh,
  };
};

const normalizeToiletGender = (src) => {
  const o = src && typeof src === "object" ? src : {};
  const good = Number(o.good ?? 0);
  const moderate = Number(o.moderate_damage ?? 0);
  const heavy = Number(o.heavy_damage ?? 0);
  const totalAll = Number(o.total_all ?? o.total ?? 0);
  const totalMh = Number(o.total_mh ?? (moderate + heavy));
  return {
    good,
    moderate_damage: moderate,
    heavy_damage: heavy,
    total_all: totalAll,
    total_mh: totalMh,
  };
};

const normalizeToilet = (src) => {
  const o = src && typeof src === "object" ? src : {};
  // support alias key laki_laki / perempuan
  const maleSrc = o.male ?? o.laki_laki ?? o.lakiLaki ?? o.lk;
  const femaleSrc = o.female ?? o.perempuan ?? o.pr;
  return {
    male: normalizeToiletGender(maleSrc),
    female: normalizeToiletGender(femaleSrc),
  };
};

const mapYesNo = (v) => {
  if (v === "YA") return "Ya";
  if (v === "TIDAK") return "Tidak";
  return v || "-";
};
const mapSudahBelum = (v) => {
  if (v === "SUDAH") return "Sudah";
  if (v === "BELUM") return "Belum";
  return v || "-";
};
const mapPeralatan = (v) => {
  if (v === "TIDAK_MEMILIKI") return "Tidak Memiliki";
  if (v === "HARUS_DIGANTI") return "Harus Diganti";
  if (v === "BAIK") return "Baik";
  if (v === "PERLU_REHABILITASI") return "Perlu Rehabilitasi";
  return v || "-";
};

// ===================== UTIL TAMBAHAN (MINIMAL) =====================
const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);

const toNum = (v, d = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};

const pickStr = (...vals) => {
  for (const v of vals) {
    if (v === 0 || v === "0") return "0";
    const s = String(v ?? "").trim();
    if (s) return s;
  }
  return "";
};

const pickFirstFinite = (...vals) => {
  for (const v of vals) {
    if (v === 0 || v === "0") return 0;
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return 0;
};

const deepMerge = (base, patch) => {
  if (!isObj(base)) base = {};
  if (!isObj(patch)) return base;
  const out = { ...base };
  for (const k of Object.keys(patch)) {
    const bv = out[k];
    const pv = patch[k];
    if (isObj(bv) && isObj(pv)) out[k] = deepMerge(bv, pv);
    else out[k] = pv;
  }
  return out;
};

function mergeMeta(meta, details) {
  const m = isObj(meta) ? meta : {};
  const d = isObj(details) ? details : {};
  const dMeta = isObj(d?.meta) ? d.meta : {};
  const dMetaAlt = !Object.keys(dMeta).length && isObj(d) ? d : {};
  return deepMerge(m, Object.keys(dMeta).length ? dMeta : dMetaAlt);
}

// Unwrap payload RPC yang sering dibungkus: { data: {...} } atau { school: {...} }
function unwrapPayload(x) {
  let cur = x;
  for (let i = 0; i < 4; i++) {
    if (!isObj(cur)) break;
    if (isObj(cur.data)) cur = cur.data;
    else if (isObj(cur.school)) cur = cur.school;
    else if (isObj(cur.detail)) cur = cur.detail;
    else if (isObj(cur.payload)) cur = cur.payload;
    else break;
  }
  return cur;
}

/* =========================================================
   Intervensi bisa ada di:
   - meta.kegiatanFisik.* (lama)
   - meta.kegiatan[] / base.kegiatan (array {lokal, kegiatan_type, ...})
   ========================================================= */
function extractIntervensiFromMeta(meta, base) {
  const m0 = isObj(meta) ? meta : {};
  const b = isObj(base) ? base : {};

  const parseMaybeJson = (v) => {
    if (typeof v === "string") {
      try {
        return JSON.parse(v);
      } catch {
        return v;
      }
    }
    return v;
  };

  // direct keys (legacy + variasi)
  let rehab = pickFirstFinite(
    m0?.kegiatanFisik?.rehab_unit,
    m0?.kegiatanFisik?.rehabilitasi_unit,
    m0?.kegiatanFisik?.rehabRuangKelas,
    m0?.rehab_unit,
    m0?.rehabilitasi_unit,
    m0?.prasarana?.classrooms?.rehab_unit,
    b?.rehab_unit
  );

  let pembangunan = pickFirstFinite(
    m0?.kegiatanFisik?.pembangunan_unit,
    m0?.kegiatanFisik?.bangun_unit,
    m0?.kegiatanFisik?.pembangunanRKB,
    m0?.pembangunan_unit,
    m0?.bangun_unit,
    m0?.prasarana?.classrooms?.pembangunan_unit,
    b?.pembangunan_unit
  );

  const candidates = [
    m0?.kegiatanFisik,
    m0?.kegiatan,
    b?.kegiatan,
    m0?.projects,
    m0?.intervensi,
    m0?.intervensiRuangKelas,
  ].map(parseMaybeJson);

  const list = candidates.find((v) => Array.isArray(v)) || null;

  const getUnit = (it) =>
    toNum(it?.lokal ?? it?.unit ?? it?.jumlah ?? it?.count ?? it?.volume ?? 0, 0);

  const getType = (it) =>
    String(
      it?.kegiatan_type ??
        it?.type ??
        it?.jenis ??
        it?.kegiatan ??
        it?.activity_name ??
        it?.name ??
        ""
    )
      .toLowerCase()
      .trim();

  if (Array.isArray(list)) {
    let rSum = 0;
    let pSum = 0;
    for (const it of list) {
      const t = getType(it);
      if (!t) continue;

      if (t === "rehab" || t.includes("rehab") || t.includes("rehabilit")) {
        rSum += getUnit(it);
        continue;
      }
      if (
        t === "pembangunan" ||
        t.includes("pembangunan") ||
        t.includes("bangun") ||
        t.includes("rkb")
      ) {
        pSum += getUnit(it);
        continue;
      }
    }
    rehab = Math.max(toNum(rehab, 0), rSum);
    pembangunan = Math.max(toNum(pembangunan, 0), pSum);
  }

  return {
    rehab_unit: toNum(rehab, 0),
    pembangunan_unit: toNum(pembangunan, 0),
  };
}

const SchoolDetailSmp = ({ schoolData }) => {
  // ====== FIX: unwrap payload + satukan meta/details ======
  const BASE0 = unwrapPayload(schoolData);
  const BASE = isObj(BASE0) ? BASE0 : {};

  // merge meta dari beberapa tempat yang umum
  const mergedMeta0 = mergeMeta(
    BASE?.meta ?? BASE?._raw?.meta,
    BASE?.details ?? BASE?._raw?.details
  );

  // kalau kegiatan ada sebagai kolom terpisah, gabungkan supaya extractor bisa baca
  const META =
    BASE?.kegiatan != null
      ? deepMerge(mergedMeta0, { kegiatan: BASE.kegiatan })
      : mergedMeta0;

  const PR = META?.prasarana || {};
  const KL = META?.kelembagaan || {};

  const handleLocationClick = () => {
    const coords =
      BASE?.coordinates ??
      (() => {
        const lat = Number(BASE?.lat ?? BASE?._raw?.lat ?? BASE?.latitude);
        const lng = Number(BASE?.lng ?? BASE?._raw?.lng ?? BASE?.longitude);
        if (Number.isFinite(lat) && Number.isFinite(lng)) return [lng, lat];
        return null;
      })();

    const validPair =
      Array.isArray(coords) &&
      coords.length === 2 &&
      coords.every((n) => Number.isFinite(Number(n)));

    if (validPair) {
      let lng = Number(coords[0]);
      let lat = Number(coords[1]);

      if (Math.abs(lat) > 90 && Math.abs(lng) <= 90) {
        [lat, lng] = [lng, lat];
      }

      if (Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
        const url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
        window.open(url, "_blank", "noopener,noreferrer");
        return;
      }
    }
    alert("Koordinat lokasi untuk sekolah ini tidak tersedia atau tidak valid.");
  };

  if (!schoolData) {
    return (
      <div className={styles.container}>
        <p>Data sekolah tidak ditemukan.</p>
      </div>
    );
  }

  /* ===================== I. IDENTITAS ===================== */
  const jenjang =
    pickStr(
      BASE?.jenjang,
      BASE?.level,
      BASE?.school_types?.code,
      META?.jenjang
    ) || "SMP";

  const statusSekolah = pickStr(BASE?.status, BASE?.status_sekolah) || "-";

  const desaLabel =
    pickStr(
      BASE?.desa,
      BASE?.village,
      BASE?._raw?.locations?.village,
      BASE?.village_name,
      META?.desa
    ) || "-";

  const kecLabel =
    pickStr(
      BASE?.kecamatan,
      BASE?.kecamatan_name,
      BASE?._raw?.locations?.subdistrict,
      BASE?._raw?.locations?.district,
      META?.kecamatan
    ) || "-";

  const alamatLabel =
    pickStr(BASE?.address, BASE?.alamat, BASE?._raw?.address) || "-";

  const npsnLabel = pickStr(BASE?.npsn, BASE?.NPSN, BASE?._raw?.npsn) || "-";

  const schoolNameLabel =
    pickStr(
      BASE?.name,
      BASE?.namaSekolah,
      BASE?.nama_sekolah,
      BASE?.school_name,
      BASE?._raw?.name
    ) || "Nama Sekolah Tidak Tersedia";

  /* ===================== II. DATA SISWA ===================== */
  const siswaL = toNum(BASE?.st_male, 0);
  const siswaP = toNum(BASE?.st_female, 0);
  const totalFromLP = siswaL + siswaP;
  const totalSiswa =
    totalFromLP > 0 ? totalFromLP : toNum(BASE?.student_count, 0);

  // ABK (aman default 0)
  const abkL = toNum(getData(META, ["siswaAbk", "total", "l"], 0), 0);
  const abkP = toNum(getData(META, ["siswaAbk", "total", "p"], 0), 0);

  /* ===================== III. RUANG KELAS & RKB ===================== */
  const classrooms =
    (isObj(PR?.classrooms) && PR.classrooms) ||
    (isObj(PR?.kelas) && PR.kelas) ||
    (isObj(PR?.ruangKelas) && PR.ruangKelas) ||
    {};

  const rusakBerat = toNum(
    pickFirstFinite(
      classrooms?.heavy_damage,
      classrooms?.classrooms_heavy_damage,
      classrooms?.heavy,
      classrooms?.rusak_berat,
      classrooms?.rusakBerat,
      BASE?.kondisiKelas?.rusakBerat,
      BASE?.class_condition?.classrooms_heavy_damage,
      BASE?.class_condition?.heavy_damage
    ),
    0
  );

  const rusakSedang = toNum(
    pickFirstFinite(
      classrooms?.moderate_damage,
      classrooms?.classrooms_moderate_damage,
      classrooms?.moderate,
      classrooms?.rusak_sedang,
      classrooms?.rusakSedang,
      BASE?.kondisiKelas?.rusakSedang,
      BASE?.class_condition?.classrooms_moderate_damage,
      BASE?.class_condition?.moderate_damage
    ),
    0
  );

  const kelasBaik = toNum(
    pickFirstFinite(
      classrooms?.classrooms_good,
      classrooms?.good,
      classrooms?.baik,
      BASE?.kondisiKelas?.baik,
      BASE?.class_condition?.classrooms_good,
      BASE?.class_condition?.good
    ),
    0
  );

  const kurangRkb = toNum(
    pickFirstFinite(
      classrooms?.kurangRkb,
      classrooms?.lacking_rkb,
      classrooms?.kurang_rkb,
      classrooms?.kurangRKB,
      BASE?.kurangRKB,
      BASE?.class_condition?.lacking_rkb
    ),
    0
  );

  const intervensi = extractIntervensiFromMeta(META, BASE);

  // tetap pakai variable lama supaya UI tidak berubah
  const rehabKegiatan = toNum(intervensi.rehab_unit, 0);
  const pembangunanKegiatan = toNum(intervensi.pembangunan_unit, 0);

  const allValues = [
    rusakBerat,
    rusakSedang,
    kurangRkb,
    rehabKegiatan,
    pembangunanKegiatan,
  ];
  const maxRoomValue = Math.max(...allValues, 1);

  const calculateHeight = (value) => {
    const numValue = Number(value) || 0;
    if (numValue === 0) return "calc(0% + 20px)";
    return `calc(${(numValue / maxRoomValue) * 100}% + 20px)`;
  };

  /* ===================== IV. STATUS TANAH & GEDUNG ===================== */
  const lahanStr = String(classrooms?.lahan ?? PR?.ukuran?.lahan ?? "").toUpperCase();
  const landOwnershipObj =
    lahanStr === "TIDAK_ADA"
      ? { tidak_ada: "Ya" }
      : lahanStr
      ? { [lahanStr.toLowerCase()]: "Ya" }
      : null;

  const buildingOwnershipObj = PR?.gedung_kepemilikan
    ? PR.gedung_kepemilikan
    : { tidak_diketahui: "Ya" };

  const landOwnership = findOwnershipStatus(landOwnershipObj, "Tidak Ada");
  const buildingOwnership = findOwnershipStatus(
    buildingOwnershipObj,
    "Tidak Diketahui"
  );

  const luasLahan = toNum(getData(PR, ["ukuran", "tanah"], 0), 0);

  /* ===================== V. LAB & PERPUSTAKAAN ===================== */
  const perpustakaan = normalizeRoom(PR?.library ?? PR?.perpustakaan);
  const labKomputer = normalizeRoom(PR?.laboratory_comp ?? PR?.lab_komputer);
  const labBahasa = normalizeRoom(
    PR?.laboratory_langua ?? PR?.laboratory_language ?? PR?.lab_bahasa
  );
  const labIpa = normalizeRoom(PR?.laboratory_ipa ?? PR?.lab_ipa);
  const labFisika = normalizeRoom(PR?.laboratory_fisika ?? PR?.lab_fisika);
  const labBiologi = normalizeRoom(PR?.laboratory_biologi ?? PR?.lab_biologi);

  /* ===================== VI. RUANG PIMPINAN & TENDIK ===================== */
  const ruangGuru = normalizeRoom(PR?.teacher_room ?? PR?.ruang_guru);
  const ruangTU = normalizeRoom(
    PR?.administration_room ?? PR?.ruang_tu ?? PR?.tata_usaha
  );

  /* ===================== VII/VIII. TOILET ===================== */
  const teachersToilet = normalizeToilet(
    PR?.teachers_toilet ?? PR?.toilet_guru ?? PR?.toiletGuru
  );
  const studentsToilet = normalizeToilet(
    PR?.students_toilet ?? PR?.toilet_siswa ?? PR?.toiletSiswa
  );

  const toiletGuruMale = normalizeRoom(teachersToilet.male);
  const toiletGuruFemale = normalizeRoom(teachersToilet.female);
  const toiletSiswaMale = normalizeRoom(studentsToilet.male);
  const toiletSiswaFemale = normalizeRoom(studentsToilet.female);

  /* ===================== IX. FURNITUR & KOMPUTER ===================== */
  const mebeulair = PR?.mebeulair || {};
  const meja =
    toNum(getData(mebeulair, ["tables", "total"], 0), 0) ||
    toNum(getData(mebeulair, ["tables", "good"], 0), 0);

  const kursi =
    toNum(getData(mebeulair, ["chairs", "total"], 0), 0) ||
    toNum(getData(mebeulair, ["chairs", "good"], 0), 0);

  const papanTulis = toNum(getData(PR, ["papan_tulis"], 0), 0);
  const komputer = toNum(getData(mebeulair, ["computer"], 0), 0);

  /* ===================== X. RUMAH DINAS ===================== */
  const official = PR?.official_residences || {};
  const rumahDinas = {
    total: toNum(official?.total, 0),
    baik: toNum(official?.good, 0),
    sedang: toNum(official?.moderate_damage, 0),
    berat: toNum(official?.heavy_damage, 0),
  };

  /* ===================== XI. DATA GURU & TENDIK ===================== */
  const staff0 = Array.isArray(BASE?.staff_summary)
    ? BASE.staff_summary[0]
    : isObj(BASE?.staff_summary)
    ? BASE.staff_summary
    : null;

  const jumlahGuru = toNum(
    getData(META, ["guru", "jumlahGuru"], undefined),
    toNum(
      staff0?.jumlah_guru ??
        staff0?.teacher_count ??
        staff0?.total_teachers ??
        0,
      0
    )
  );

  const kekuranganGuru = toNum(getData(META, ["guru", "kekuranganGuru"], 0), 0);

  const tendik = toNum(
    getData(META, ["tendik"], undefined),
    toNum(staff0?.tendik ?? staff0?.staff_count ?? 0, 0)
  );

  /* ===================== XII. KELEMBAGAAN ===================== */
  const kelembagaan = {
    peralatanRumahTangga: mapPeralatan(
      getData(KL, ["peralatanRumahTangga"], "-")
    ),
    pembinaan: mapSudahBelum(getData(KL, ["pembinaan"], "-")),
    asesmen: mapSudahBelum(getData(KL, ["asesmen"], "-")),
    menyelenggarakanBelajar: mapYesNo(
      getData(KL, ["menyelenggarakanBelajar"], "-")
    ),
    melaksanakanRekomendasi: mapYesNo(
      getData(KL, ["melaksanakanRekomendasi"], "-")
    ),
    siapDievaluasi: mapYesNo(getData(KL, ["siapDievaluasi"], "-")),
    bopPengelola: mapYesNo(getData(KL, ["bop", "pengelola"], "-")),
    bopTenagaPeningkatan: mapYesNo(
      getData(KL, ["bop", "tenagaPeningkatan"], "-")
    ),
    izinPengendalian: mapYesNo(
      getData(KL, ["perizinan", "pengendalian"], "-")
    ),
    izinKelayakan: mapYesNo(getData(KL, ["perizinan", "kelayakan"], "-")),
    silabus: mapYesNo(getData(KL, ["kurikulum", "silabus"], "-")),
    kompetensiDasar: mapYesNo(
      getData(KL, ["kurikulum", "kompetensiDasar"], "-")
    ),
  };

  return (
    <div className={styles.container}>
      {/* ===================== I. IDENTITAS SEKOLAH ===================== */}
      <div className={styles.header}>
        <h1 className={styles.schoolName}>{schoolNameLabel}</h1>
        <div className={styles.schoolInfo}>
          <div className={styles.infoRow}>
            <span className={styles.label}>Jenjang</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{jenjang}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.label}>NPSN</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{npsnLabel}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.label}>Alamat</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{alamatLabel}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.label}>Desa</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{desaLabel}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.label}>Kecamatan</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{kecLabel}</span>
          </div>
          <div className={styles.infoRow}>
            <span className={styles.label}>Jumlah Siswa (Total)</span>
            <span className={styles.colon}>:</span>
            <span className={styles.value}>{totalSiswa}</span>
          </div>
        </div>
        <button onClick={handleLocationClick} className={styles.locationButton}>
          📍 Lihat Lokasi di Google Maps
        </button>
      </div>

      {/* ===================== II. DATA SISWA ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>II. Data Siswa</h2>
        <div className={styles.card}>
          <div className={styles.dataRow}>
            <span>Jumlah Siswa Laki-Laki: {siswaL}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Jumlah Siswa Perempuan: {siswaP}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Jumlah Siswa (Total): {totalSiswa}</span>
          </div>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Siswa Berkebutuhan Khusus</h3>
            <div className={styles.dataRow}>
              <span>ABK Laki-Laki: {abkL}</span>
            </div>
            <div className={styles.dataRow}>
              <span>ABK Perempuan: {abkP}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== III. KONDISI & INTERVENSI RUANG KELAS ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>III. Kondisi & Intervensi Ruang Kelas</h2>
        <div className={styles.card}>
          <div className={styles.chartContainer}>
            <div className={styles.chart}>
              <div className={styles.barContainer}>
                <div
                  className={`${styles.bar} ${styles.barRed}`}
                  style={{ height: calculateHeight(rusakBerat) }}
                >
                  <span className={styles.barLabel}>{rusakBerat}</span>
                </div>
                <span className={styles.barText}>Rusak Berat</span>
              </div>
              <div className={styles.barContainer}>
                <div
                  className={`${styles.bar} ${styles.barYellow}`}
                  style={{ height: calculateHeight(rusakSedang) }}
                >
                  <span className={styles.barLabel}>{rusakSedang}</span>
                </div>
                <span className={styles.barText}>Rusak Sedang</span>
              </div>
              <div className={styles.barContainer}>
                <div
                  className={`${styles.bar} ${styles.barBlue}`}
                  style={{ height: calculateHeight(kurangRkb) }}
                >
                  <span className={styles.barLabel}>{kurangRkb}</span>
                </div>
                <span className={styles.barText}>Kurang RKB</span>
              </div>
              <div className={styles.barContainer}>
                <div
                  className={`${styles.bar} ${styles.barPurple}`}
                  style={{ height: calculateHeight(rehabKegiatan) }}
                >
                  <span className={styles.barLabel}>{rehabKegiatan}</span>
                </div>
                <span className={styles.barText}>Rehabilitasi</span>
              </div>
              <div className={styles.barContainer}>
                <div
                  className={`${styles.bar} ${styles.barOrange}`}
                  style={{ height: calculateHeight(pembangunanKegiatan) }}
                >
                  <span className={styles.barLabel}>{pembangunanKegiatan}</span>
                </div>
                <span className={styles.barText}>Pembangunan RKB</span>
              </div>
            </div>
          </div>

          <div className={styles.dataRow}>
            <span>Kondisi Kelas Baik (Total Ruangan Bersih): {kelasBaik}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Kondisi Kelas Rusak Sedang: {rusakSedang}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Kondisi Kelas Rusak Berat: {rusakBerat}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Kekurangan RKB: {kurangRkb}</span>
          </div>
        </div>
      </div>

      {/* ===================== IV. STATUS TANAH, GEDUNG & BANGUNAN ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>IV. Status Tanah, Gedung & Bangunan</h2>
        <div className={styles.card}>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Status Tanah</h3>
            <div className={styles.dataRow}>
              <span>Kepemilikan: {landOwnership}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Lahan Tersedia: {luasLahan} m²</span>
            </div>
          </div>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Status Gedung</h3>
            <div className={styles.dataRow}>
              <span>Kepemilikan: {buildingOwnership}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== V. PERPUSTAKAAN & LABORATORIUM ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>V. Perpustakaan & Laboratorium</h2>
        <div className={styles.card}>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Ruang Perpustakaan</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {perpustakaan.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {perpustakaan.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {perpustakaan.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {perpustakaan.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {perpustakaan.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Lab. Komputer</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {labKomputer.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {labKomputer.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {labKomputer.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {labKomputer.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {labKomputer.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Lab. Bahasa</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {labBahasa.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {labBahasa.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {labBahasa.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {labBahasa.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {labBahasa.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Lab. IPA</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {labIpa.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {labIpa.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {labIpa.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {labIpa.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {labIpa.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Lab. Fisika</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {labFisika.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {labFisika.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {labFisika.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {labFisika.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {labFisika.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Lab. Biologi</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {labBiologi.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {labBiologi.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {labBiologi.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {labBiologi.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {labBiologi.total_all}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== VI. RUANG PIMPINAN & TENDIK (KEPSEK DIHAPUS) ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>
          VI. Ruang Pimpinan & Tenaga Kependidikan
        </h2>
        <div className={styles.card}>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Ruang Guru</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {ruangGuru.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {ruangGuru.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {ruangGuru.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {ruangGuru.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {ruangGuru.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Ruang Tata Usaha</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {ruangTU.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {ruangTU.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {ruangTU.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Ruang Rusak: {ruangTU.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Ruang (Total): {ruangTU.total_all}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== VII. TOILET GURU ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>VII. Toilet Guru</h2>
        <div className={styles.card}>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Laki-laki</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {toiletGuruMale.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {toiletGuruMale.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {toiletGuruMale.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Rusak: {toiletGuruMale.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Total: {toiletGuruMale.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Perempuan</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {toiletGuruFemale.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {toiletGuruFemale.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {toiletGuruFemale.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Rusak: {toiletGuruFemale.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Total: {toiletGuruFemale.total_all}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== VIII. TOILET SISWA ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>VIII. Toilet Siswa</h2>
        <div className={styles.card}>
          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Laki-laki</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {toiletSiswaMale.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {toiletSiswaMale.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {toiletSiswaMale.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Rusak: {toiletSiswaMale.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Total: {toiletSiswaMale.total_all}</span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Perempuan</h3>
            <div className={styles.dataRow}>
              <span>Kondisi Baik: {toiletSiswaFemale.good}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Sedang: {toiletSiswaFemale.moderate_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Rusak Berat: {toiletSiswaFemale.heavy_damage}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Total Rusak: {toiletSiswaFemale.total_mh}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Jumlah Total: {toiletSiswaFemale.total_all}</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== IX. FURNITUR & KOMPUTER ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>IX. Furnitur & Komputer</h2>
        <div className={styles.card}>
          <div className={styles.dataRow}>
            <span>Jumlah Meja: {meja}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Jumlah Kursi: {kursi}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Jumlah Papan Tulis: {papanTulis}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Jumlah Komputer: {komputer}</span>
          </div>
        </div>
      </div>

      {/* ===================== X. RUMAH DINAS ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>X. Rumah Dinas</h2>
        <div className={styles.card}>
          <div className={styles.dataRow}>
            <span>Jumlah Rumah Dinas: {rumahDinas.total}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Kondisi Baik: {rumahDinas.baik}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Rusak Sedang: {rumahDinas.sedang}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Rusak Berat: {rumahDinas.berat}</span>
          </div>
        </div>
      </div>

      {/* ===================== XI. DATA GURU & TENDIK ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>XI. Data Guru & Tendik</h2>
        <div className={styles.card}>
          <div className={styles.dataRow}>
            <span>Jumlah Guru: {jumlahGuru}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Kekurangan Guru: {kekuranganGuru}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Tenaga Kependidikan (Tendik): {tendik}</span>
          </div>
        </div>
      </div>

      {/* ===================== XII. KELEMBAGAAN ===================== */}
      <div className={styles.section}>
        <h2 className={styles.sectionTitle}>XII. Kelembagaan</h2>
        <div className={styles.card}>
          <div className={styles.dataRow}>
            <span>Alat Rumah Tangga: {kelembagaan.peralatanRumahTangga}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Pembinaan: {kelembagaan.pembinaan}</span>
          </div>
          <div className={styles.dataRow}>
            <span>Asesmen: {kelembagaan.asesmen}</span>
          </div>
          <div className={styles.dataRow}>
            <span>
              Menyelenggarakan Belajar: {kelembagaan.menyelenggarakanBelajar}
            </span>
          </div>
          <div className={styles.dataRow}>
            <span>
              Melaksanakan Rekomendasi: {kelembagaan.melaksanakanRekomendasi}
            </span>
          </div>
          <div className={styles.dataRow}>
            <span>Siap Dievaluasi: {kelembagaan.siapDievaluasi}</span>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>BOP</h3>
            <div className={styles.dataRow}>
              <span>Pengelola: {kelembagaan.bopPengelola}</span>
            </div>
            <div className={styles.dataRow}>
              <span>
                Tenaga Peningkatan: {kelembagaan.bopTenagaPeningkatan}
              </span>
            </div>
          </div>

          <div className={styles.subsection}>
            <h3 className={styles.subsectionTitle}>Perizinan & Kurikulum</h3>
            <div className={styles.dataRow}>
              <span>Izin Pengendalian: {kelembagaan.izinPengendalian}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Izin Kelayakan: {kelembagaan.izinKelayakan}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Silabus: {kelembagaan.silabus}</span>
            </div>
            <div className={styles.dataRow}>
              <span>Kompetensi Dasar: {kelembagaan.kompetensiDasar}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SchoolDetailSmp;
